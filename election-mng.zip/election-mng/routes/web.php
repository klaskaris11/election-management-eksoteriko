<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/profile', function(){
	return view('profile');
})->name('profile')->middleware('auth');

Route::get('/eterodimotes', function(){
	return view('eterodimotes');
})->name('eterodimotes')->middleware('auth');

Route::get('/print-eterodimotis', function(){
	return view('printEterodimotis');
})->name('print-eterodimotis')->middleware('auth');

//Resources
Route::resource('test', 'TestController');
Route::resource('api/users', 'UserController')->middleware('auth');
Route::resource('api/eterodimotes', 'EterodimotesController')->middleware('auth');
