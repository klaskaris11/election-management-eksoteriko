<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Eterodimotes extends Model
{
    //
}
