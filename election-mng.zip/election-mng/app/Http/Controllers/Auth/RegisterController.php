<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;


class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    public function register(Request $request)
    {
        $this->validator($request->all())->validate();
        event(new Registered($user = $this->create($request->all())));
        // $this->guard()->login($user);
        return $this->registered($request, $user)
                        ?: redirect($this->redirectPath());
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'firstname'         => ['required', 'string', 'max:190'],
            'lastname'          => ['required', 'string', 'max:190'],
            'address'           => ['required', 'string', 'max:190'],
            'address_num'       => ['required', 'string', 'max:20'],
            'identity_kind'     => ['required', 'string', 'max:190'],
            'identity_num'      => ['required', 'string', 'max:190', 'unique:users'],
            'identity_document' => ['required'],
            'bank'              => ['required'],
            'iban'              => ['required'],
            'sex'               => ['required', 'string', 'max:190'],
            'phone'             => ['required', 'string', 'max:10'],
            'municipality'      => ['required', 'string', 'max:190'],
            'birthdate'         => ['required', 'date'],
            'email'             => ['required', 'string', 'email', 'max:190', 'unique:users'],
            'password'          => ['required', 'string', 'min:8'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $request = request();

        $profileImage = $request->file('identity_document');
        $profileImageSaveAsName = time() . "uid-" . $data['identity_num'] . '.' . $profileImage->getClientOriginalExtension();
        $upload_path = 'storage/docs/';
        $profile_image_url = $upload_path . $profileImageSaveAsName;
        $success = $profileImage->move($upload_path, $profileImageSaveAsName);

        return User::create([
            'firstname'         => $data['firstname'],
            'lastname'          => $data['lastname'],
            'email'             => $data['email'],
            'password'          => Hash::make($data['password']),
            'address'           => $data['address'],
            'address_num'       => $data['address_num'],
            'identity_kind'     => $data['identity_kind'],
            'identity_num'      => $data['identity_num'],
            'identity_document' => $profile_image_url,
            'bank'              => $data['bank'],
            'iban'              => $data['iban'],
            'sex'               => $data['sex'],
            'phone'             => $data['phone'],
            'municipality'      => $data['municipality'],
            'birthdate'         => $data['birthdate'],
        ]);
    }
}
