<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserHistory;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $editHistory = \DB::table('user_histories')->where('user_id', Auth::user()->id)->get();
        $aitiseisEterodimoti = \DB::table('eterodimotes')->where('user_id', Auth::user()->id)->get();
        $history = array('userUpdates' => $editHistory, 'eterodimotesList' => $aitiseisEterodimoti);
        return view('home')->with( 'history', $history);
    }
}
