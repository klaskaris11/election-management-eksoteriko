<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Eterodimotes;
use App\UserHistory;

class EterodimotesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $request->validate([
            'zip'               => ['required', 'string', 'max:5'],
            'city'              => ['required', 'string', 'max:190'],
            'address'           => ['required', 'string', 'max:190'],
            'address_num'       => ['required', 'string', 'max:20'],
            'phone'             => ['required', 'string', 'max:10'],
            'municipality'      => ['required', 'string', 'max:190'],
            'deko_document'     => ['required'],
        ]);

        $deko = $request->file('deko_document');
        $dekoSaveAsName = time() . "uid-" . $request->input('user_id') . '.' . $deko->getClientOriginalExtension();
        $upload_path = 'storage/eterodimotes/';
        $deko_url = $upload_path . $dekoSaveAsName;
        $success = $deko->move($upload_path, $dekoSaveAsName);

        $eterodimotis                = new Eterodimotes;
        $eterodimotis->user_id       = $request->input('user_id');
        $eterodimotis->city          = $request->input('city');
        $eterodimotis->zip           = $request->input('zip');
        $eterodimotis->address       = $request->input('address');
        $eterodimotis->address_num   = $request->input('address_num');
        $eterodimotis->municipality  = $request->input('municipality');
        $eterodimotis->phone         = $request->input('phone');
        $eterodimotis->deko_document = $deko_url;

        if($eterodimotis->save()){           
            $msg = 'Η αίτηση αποθηκεύτηκε με επιτυχία. Από την αρχική μπορείτε να την εκτυπώσετε';
            $condition = 'success';
        }else{
            $msg = 'Εμφανίστηκε σφάλμα';
            $condition = 'error';
        }
        return redirect('/eterodimotes')->with($condition, $msg);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $eterodimotis = Eterodimotes::find($id);
        return response()->json($eterodimotis);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
