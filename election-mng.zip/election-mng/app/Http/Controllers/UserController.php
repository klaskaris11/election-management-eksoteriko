<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\UserHistory;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        header('Access-Control-Allow-Origin: *');
        $request->validate([
            'firstname'         => ['required', 'string', 'max:190'],
            'lastname'          => ['required', 'string', 'max:190'],
            'address'           => ['required', 'string', 'max:190'],
            'address_num'       => ['required', 'string', 'max:20'],
            'sex'               => ['required', 'string', 'max:190'],
            'phone'             => ['required', 'string', 'max:10'],
            'municipality'      => ['required', 'string', 'max:190'],
            'email'             => ['required', 'string', 'email', 'max:190'],
        ]);
        //Find an Item
        $user = User::find($id);
        $user->firstname    = $request->input('firstname');
        $user->lastname     = $request->input('lastname');
        $user->address      = $request->input('address');
        $user->address_num  = $request->input('address_num');
        $user->sex          = $request->input('sex');
        $user->phone        = $request->input('phone');
        $user->municipality = $request->input('municipality');
        $user->email        = $request->input('email');
        if($user->save()){
            $userHistory = new UserHistory;
            $userHistory->type = "Επεξεργασία Προφίλ";        
            $userHistory->user_id = $id;
            $userHistory->save();
            $msg = 'Το προφίλ σας άλλαξε με επιτυχία.';
            $condition = 'success';
        }else{
            $msg = 'Εμφανίστηκε σφάλμα';
            $condition = 'error';
        }
        return redirect('/profile')->with($condition, $msg);
        //return response()->json($user); 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
