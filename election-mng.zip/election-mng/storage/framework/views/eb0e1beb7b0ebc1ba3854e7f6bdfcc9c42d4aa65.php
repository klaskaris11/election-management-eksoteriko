<?php $__env->startSection('page-name'); ?>
Home Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row" id="electionRow" style="display: none;">
    <div class="col-xl-12">
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <strong><u>ΠΡΟΣΟΧΗ!</u> Έχετε επιλεχθεί ως εφορευτική επιτροπή για τις ερχόμενες εκλογές.</strong>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-12">
        <!-- START card-->
        <div class="card card-default">
            <div class="card-header border-bottom">          
                <a class="float-right fa-110x">
                    <em class="fas fa-table"></em>
                </a>
                <div class="card-title">
                 <h4 class="mb-0">Ιστορικό Αλλαγών προφίλ</h4>
             </div>
         </div>
         <div class="card-body">
            <!-- START table-responsive-->
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Τύπος Ενέργειας</th>
                            <th>Ημερομηνία Ενέργειας</th>
                        </tr>
                    </thead>
                    <tbody>                 
                        <?php if(sizeof($history['userUpdates']) > 0): ?>           
                        <?php $__currentLoopData = $history['userUpdates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->type); ?></td>
                            <td><?php echo e(date('D, d/m/Y - H:i:s', strtotime($p->created_at))); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                        <?php else: ?>
                        <tr>
                            <td class="text-center text-danger" colspan="3">Καμία Καταχώρηση</td>
                        </tr>
                        <?php endif; ?>                            
                    </tbody>
                </table>
            </div>
            <!-- END table-responsive-->
        </div>
    </div>
    <!-- END card-->
</div>
</div>

<div class="row">
    <div class="col-xl-12">
        <!-- START card-->
        <div class="card card-default">
            <div class="card-header border-bottom">          
                <a class="float-right fa-110x">
                    <em class="fas fa-table"></em>
                </a>
                <div class="card-title">
                 <h4 class="mb-0">Ιστορικό Αιτήσεων Ετεροδημότη</h4>
             </div>
         </div>
         <div class="card-body">
            <!-- START table-responsive-->
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Δημότης</th>
                            <th>Πόλη</th>
                            <th>Διεύθυνση</th>
                            <th>Τηλέφωνο</th>
                            <th>Τ.Κ</th>
                            <th>Έγγραφο ΔΕΚΟ</th>
                            <th>Ημερομηνία Ενέργειας</th>
                            <th>Εκτύπωση</th>
                        </tr>
                    </thead>
                    <tbody>                 
                        <?php if(sizeof($history['eterodimotesList']) > 0): ?>           
                        <?php $__currentLoopData = $history['eterodimotesList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->municipality); ?></td>
                            <td><?php echo e($p->city); ?></td>
                            <td><?php echo e($p->address . $p->address_num); ?></td>
                            <td><?php echo e($p->phone); ?></td>
                            <td><?php echo e($p->zip); ?></td>
                            <td><a href="<?php echo e(asset($p->deko_document)); ?>" target="_blank"><?php echo e($p->deko_document); ?></a></td>
                            <td><?php echo e(date('D, d/m/Y - H:i:s', strtotime($p->created_at))); ?></td>
                            <td> 
                                <button data-id="<?php echo e($p->id); ?>" class="btn btn-sm btn-inverse" id="printBtn"><i class="fas fa-print fa-150x"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                        <?php else: ?>
                        <tr>
                            <td class="text-center text-danger" colspan="9">-- Καμία Καταχώρηση --</td>
                        </tr>
                        <?php endif; ?>                            
                    </tbody>
                </table>
            </div>
            <!-- END table-responsive-->
        </div>
    </div>
    <!-- END card-->
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $.ajax({
            method: 'GET',
            url: 'http://127.0.0.1:8001/citizen/' + "<?php echo e(Auth::user()->identity_num); ?>"
        }).done(function(citizen){   
            if(citizen.election == true){        //0 for not eforeutiki, 1 for eforeutiki
                $("#electionRow").css('display', 'block');
            }
        });


        $('body').on('click', '#printBtn', function(e){
            $.ajax({
                method: 'GET',
                url: 'api/eterodimotes/' + $(this).data('id')
            }).done(function(list){ 
                localStorage.setItem('Δημότης',list.municipality);
                localStorage.setItem('Πόλη',list.city);
                localStorage.setItem('Οδός',list.address);
                localStorage.setItem('Αριθμός',list.address_num);
                localStorage.setItem('Τηλέφωνο',list.phone);
                localStorage.setItem('ΤΚ',list.zip);
                localStorage.setItem('Ημερομηνία Έκδοσης',list.created_at);
                localStorage.setItem('id',list.id);
                window.location.href = "<?php echo e(route('print-eterodimotis')); ?>";

            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/election-mng/resources/views/home.blade.php ENDPATH**/ ?>