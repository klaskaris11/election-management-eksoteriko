<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <link rel="icon" type="image/x-icon" href="favicon.ico">
   <title>Election-Mng</title>
   <!-- =============== VENDOR STYLES ===============-->
   <!-- FONT AWESOME-->
   <link rel="stylesheet" href="<?php echo e(asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-brands.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-regular.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-solid.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fontawesome.css')); ?>">
   <!-- SIMPLE LINE ICONS-->
   <link rel="stylesheet" href="<?php echo e(asset('vendor/simple-line-icons/css/simple-line-icons.css')); ?>">
   <!-- ANIMATE.CSS-->
   <link rel="stylesheet" href="<?php echo e(asset('vendor/animate.css/animate.css')); ?>">
   <!-- WHIRL (spinners)-->
   <link rel="stylesheet" href="<?php echo e(asset('vendor/whirl/dist/whirl.css')); ?>">
   <!-- =============== BOOTSTRAP STYLES ===============-->
   <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" id="bscss">
   <!-- =============== APP STYLES ===============-->
   <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" id="maincss">
   <link rel="stylesheet" href="<?php echo e(asset('css/theme-e.css')); ?>" id="maincss">
</head>

<body>
   <div class="wrapper">
      <!-- top navbar-->
      <header class="topnavbar-wrapper">
         <!-- START Top Navbar-->
         <nav class="navbar topnavbar">
            <!-- START navbar header-->
            <div class="navbar-header">
               <a class="navbar-brand" href="#/">
                  <div class="brand-logo">
                     <img class="img-fluid" src="img/logo.png" alt="App Logo">
                  </div>
                  <div class="brand-logo-collapsed">
                     <img class="img-fluid" src="img/logo-single.png" alt="App Logo">
                  </div>
               </a>
            </div>
            <!-- END navbar header-->
            <!-- START Left navbar-->
            <ul class="navbar-nav mr-auto flex-row">
               <li class="nav-item">
                  <!-- Button used to collapse the left sidebar. Only visible on tablet and desktops-->
                  <a class="nav-link d-none d-md-block d-lg-block d-xl-block" href="#" data-trigger-resize="" data-toggle-state="aside-collapsed">
                     <em class="fas fa-bars"></em>
                  </a>
                  <!-- Button to show/hide the sidebar on mobile. Visible on mobile only.-->
                  <a class="nav-link sidebar-toggle d-md-none" href="#" data-toggle-state="aside-toggled" data-no-persist="true">
                     <em class="fas fa-bars"></em>
                  </a>
               </li>               
            </ul>
            <!-- END Left navbar-->
            <!-- START Right Navbar-->
            <ul class="navbar-nav flex-row">              
               <!-- Fullscreen (only desktops)-->
               <li class="nav-item d-none d-md-block">
                  <a class="nav-link" href="#" data-toggle-fullscreen="">
                     <em class="fas fa-expand"></em>
                  </a>
               </li>
               <!-- START Alert menu-->
               <li class="nav-item dropdown dropdown-list">
                  <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" data-toggle="dropdown">
                     <em class="icon-people mr-1"></em> <?php echo e(Auth::user()->lastname); ?> <?php echo e(Auth::user()->firstname); ?>

                  </a>
                  <!-- START Dropdown menu-->
                  <div class="dropdown-menu dropdown-menu-right animated flipInX">
                     <div class="dropdown-item">
                        <!-- START list group-->
                        <div class="list-group">
                           <!-- list item
                           <div class="list-group-item list-group-item-action">
                              <div class="media">
                                 <div class="align-self-start mr-2">
                                    <em class="fab fa-twitter fa-2x text-info"></em>
                                 </div>
                                 <div class="media-body">
                                    <p class="m-0">New followers</p>
                                    <p class="m-0 text-muted text-sm">1 new follower</p>
                                 </div>
                              </div>
                           </div>  -->                        
                        </div>
                        <!-- END list group-->
                     </div>
                  </div>
                  <!-- END Dropdown menu-->
               </li>
               <!-- END Alert menu-->    
               <!-- Search icon-->
               <li class="nav-item" title="Αποσύνδεση">
                  <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                     <em class="fas fa-sign-out-alt"></em>
                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                     <?php echo csrf_field(); ?>
                  </form>
               </li>          
            </ul>
            <!-- END Right Navbar-->
         </nav>
         <!-- END Top Navbar-->
      </header>
      <!-- sidebar-->
      <aside class="aside-container">
         <!-- START Sidebar (left)-->
         <div class="aside-inner">
            <nav class="sidebar" data-sidebar-anyclick-close="">
               <!-- START sidebar nav-->
               <ul class="sidebar-nav">
                  <!-- Iterates over all sidebar items-->
                  <li class="nav-heading ">
                     <span data-localize="sidebar.heading.HEADER">Main Navigation</span>
                  </li>
                  <li class="<?php echo e(Request::is('home') ? 'active' : ''); ?>">
                     <a href="/home" title="Home">
                        <em class="fas fa-home"></em>
                        <span data-localize="sidebar.nav.WIDGETS">Home</span>
                     </a>
                  </li>
                  <li class="<?php echo e(Request::is('profile') ? 'active' : ''); ?>">
                     <a href="<?php echo e(route('profile')); ?>" title="Layouts">
                        <em class="fas fa-user-cog"></em>
                        <span>Το Προφίλ μου</span>
                     </a>
                  </li>
                  <li class="<?php echo e(Request::is('eterodimotes') ? 'active' : ''); ?>">
                     <a href="<?php echo e(route('eterodimotes')); ?>" title="Layouts">
                        <em class="far fa-address-card"></em>
                        <span>Αίτηση Ετεροδημότη</span>
                     </a>
                  </li>
               </ul>
            </nav>
         </div>
         <!-- END Sidebar (left)-->
      </aside>     
      <!-- Main section-->
      <section class="section-container">
         <!-- Page content-->
         <div class="content-wrapper">
            <div class="content-heading">
               <div><?php echo $__env->yieldContent('page-name'); ?>
                  <small>Χρήστης: <?php echo e(Auth::user()->lastname); ?> <?php echo e(Auth::user()->firstname); ?> (<?php echo e(Auth::user()->identity_num); ?>)</small>
               </div>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
         </div>         
      </section>
      <!-- Page footer-->
      <footer class="footer-container">
         <span>&copy; 2018 - Angle</span>
      </footer>
   </div>
   <!-- =============== VENDOR SCRIPTS ===============-->
   <!-- MODERNIZR-->
   <script src="<?php echo e(asset('vendor/modernizr/modernizr.custom.js')); ?>"></script>
   <!-- JQUERY-->
   <script src="<?php echo e(asset('vendor/jquery/dist/jquery.js')); ?>"></script>
   <!-- BOOTSTRAP-->
   <script src="<?php echo e(asset('vendor/popper.js/dist/umd/popper.js')); ?>"></script>
   <script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.js')); ?>"></script>
   <!-- STORAGE API-->
   <script src="<?php echo e(asset('vendor/js-storage/js.storage.js')); ?>"></script>
   <!-- JQUERY EASING-->
   <script src="<?php echo e(asset('vendor/jquery.easing/jquery.easing.js')); ?>"></script>
   <!-- ANIMO-->
   <script src="<?php echo e(asset('vendor/animo/animo.js')); ?>"></script>
   <!-- SCREENFULL-->
   <script src="<?php echo e(asset('vendor/screenfull/dist/screenfull.js')); ?>"></script>
   <!-- LOCALIZE-->
   <script src="<?php echo e(asset('vendor/jquery-localize/dist/jquery.localize.js')); ?>"></script>
   <!-- FILESTYLE-->
   <script src="<?php echo e(asset('vendor/bootstrap-filestyle/src/bootstrap-filestyle.js')); ?>"></script>
   <!-- =============== PAGE VENDOR SCRIPTS ===============-->
   <!-- =============== APP SCRIPTS ===============-->
   <script src="<?php echo e(asset('js/app.js')); ?>"></script>
   <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH D:\wamp64\www\election-mng\resources\views/layouts/mainapp.blade.php ENDPATH**/ ?>