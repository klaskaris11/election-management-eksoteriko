<?php $__env->startSection('page-name'); ?>
Επεξεργασία Προφίλ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-lg-5">
        <div class="card card-default">
            <div class="card-header border-bottom">
                <div class="card-title">
                 <h4 class="mb-0">Στοιχεία Εκλογέα</h4>
             </div>
         </div>
         <div class="card-body">
            <ul class="list-group">
                <li class="list-group-item list-group-item-danger"><b>Αρ. Ταυτότητας:</b> <?php echo e(Auth::user()->identity_num); ?></li>
                <li class="list-group-item"><b>Όνομα:</b> <?php echo e(Auth::user()->firstname); ?></li>
                <li class="list-group-item"><b>Επίθετο:</b> <?php echo e(Auth::user()->lastname); ?></li>
                <li class="list-group-item"><b>Ημ. Γέννησης:</b> <?php echo e(date('d/m/Y', strtotime(Auth::user()->birthdate))); ?> (Ετών <?php echo e(round($diff = (Carbon\Carbon::parse(Auth::user()->birthdate)->diffInDays(Carbon\Carbon::now()) )/360)); ?>)</li>
                <li class="list-group-item"><b>Φύλλο:</b> <?php echo e(Auth::user()->sex); ?></li>
                <li class="list-group-item"><b>Δημότης:</b> <?php echo e(Auth::user()->municipality); ?></li>
          </ul>
      </div>
  </div>
</div>

<div class="col-lg-7">
    <!-- START card-->
    <div class="card card-default">
        <div class="card-header border-bottom">
            <div class="card-title">
             <h4 class="mb-0">Επεξεργασία Προφιλ</h4>
         </div>
     </div>
     <div class="card-body">
        <h4 class="text-center py-2"><i class="fas fa-user-cog fa-4x"></i></h4>
        <form class="mb-3" method="POST" action="/api/users/<?php echo e(Auth::user()->id); ?>" novalidate>
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PATCH')); ?>

            <div class="form-row">
                <div class="col-lg-6 mt-2">
                    <label for="firstname">Όνομα <span class="text-warning text-bold">(*)</span></label>
                    <input class="form-control <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="firstname" id="firstname" type="text" placeholder="Όνομα.." autocomplete="off" value="<?php echo e(Auth::user()->firstname); ?>" required>
                    <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="col-lg-6 mt-2">
                    <label for="lastname">Επίθετο <span class="text-warning text-bold">(*)</span></label>
                    <input class="form-control <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="lastname" id="lastname" type="text" placeholder="Επίθετο.." autocomplete="off" value="<?php echo e(Auth::user()->lastname); ?>" required>
                    <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                        <!--<div class="col-lg-4 mt-2">
                            <label for="password">Κωδικός <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" id="password" type="password" placeholder="Κωδικός.." autocomplete="off" required>
                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>-->
                    </div>

                    <div class="form-row mt-1">
                        <div class="col-lg-6 mt-2">
                            <label for="email">Email <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" id="email" type="email" placeholder="Email.." autocomplete="off" value="<?php echo e(Auth::user()->email); ?>" required>
                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="col-lg-4 mt-2">
                            <label for="address">Διεύθυνση <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address" id="address" type="text" placeholder="Διεύθυνση.." autocomplete="off" value="<?php echo e(Auth::user()->address); ?>" required>
                            <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="col-lg-2 mt-2">
                            <label for="address_num">Αριθμός <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control <?php if ($errors->has('address_num')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address_num'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address_num" id="address_num" type="text" placeholder="Αριθμός.." autocomplete="off" value="<?php echo e(Auth::user()->address_num); ?>" required>
                            <?php if ($errors->has('address_num')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address_num'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-row mt-1">
                     <div class="col-lg-4 mt-2">
                        <label for="sex">Φύλλο <span class="text-warning text-bold">(*)</span></label>
                        <select class="custom-select <?php if ($errors->has('sex')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sex'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="sex" id="sex" required>
                            <option value="" selected>-- Επιλογή --</option>
                            <option value="Άνδρας">Άνδρας</option>
                            <option value="Γυναίκα">Γυναίκα</option>
                        </select>
                        <?php if ($errors->has('sex')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sex'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <label for="phone">Τηλέφωνο <span class="text-warning text-bold">(*)</span></label>
                        <input class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(Auth::user()->phone); ?>" maxlength="10" name="phone" id="phone" type="text" placeholder="Τηλέφωνο.." autocomplete="off" required>
                        <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-lg-4 mt-2">
                        <label for="municipality">Δημότης <span class="text-warning text-bold">(*)</span></label>
                        <select class="custom-select <?php if ($errors->has('municipality')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('municipality'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="municipality" value="<?php echo e(Auth::user()->municipality); ?>" name="municipality" required>
                            <option value="">-- Επιλέξτε Δήμο --</option><option value="9015">ΑΒΔΗΡΩΝ/ΞΑΝΘΗΣ</option><option value="9274">ΑΓΑΘΟΝΗΣΙΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9097">ΑΓΙΑΣ/ΛΑΡΙΣΗΣ</option><option value="9179">ΑΓΙΑΣ ΒΑΡΒΑΡΑΣ/ΑΤΤΙΚΗΣ</option><option value="9167">ΑΓΙΑΣ ΠΑΡΑΣΚΕΥΗΣ/ΑΤΤΙΚΗΣ</option><option value="9314">ΑΓΙΟΥ ΒΑΣΙΛΕΙΟΥ/ΡΕΘΥΜΝΗΣ</option><option value="9194">ΑΓΙΟΥ ΔΗΜΗΤΡΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9262">ΑΓΙΟΥ ΕΥΣΤΡΑΤΙΟΥ/ΛΕΣΒΟΥ</option><option value="9310">ΑΓΙΟΥ ΝΙΚΟΛΑΟΥ/ΛΑΣΙΘΙΟΥ</option><option value="9180">ΑΓΙΩΝ ΑΝΑΡΓΥΡΩΝ - ΚΑΜΑΤΕΡΟΥ/ΑΤΤΙΚΗΣ</option><option value="9207">ΑΓΚΙΣΤΡΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9156">ΑΓΡΑΦΩΝ/ΕΥΡΥΤΑΝΙΑΣ</option><option value="9123">ΑΓΡΙΝΙΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option><option value="9186">ΑΘΗΝΑΙΩΝ/ΑΤΤΙΚΗΣ</option><option value="9181">ΑΙΓΑΛΕΩ/ΑΤΤΙΚΗΣ</option><option value="9130">ΑΙΓΙΑΛΕΙΑΣ/ΑΧΑΪΑΣ</option><option value="9208">ΑΙΓΙΝΑΣ/ΑΤΤΙΚΗΣ</option><option value="9124">ΑΚΤΙΟΥ - ΒΟΝΙΤΣΑΣ/ΑΙΤΩΛ/ΝΙΑΣ</option><option value="9023">ΑΛΕΞΑΝΔΡΕΙΑΣ/ΗΜΑΘΙΑΣ</option><option value="9006">ΑΛΕΞΑΝΔΡΟΥΠΟΛΗΣ/ΕΒΡΟΥ</option><option value="9142">ΑΛΙΑΡΤΟΥ/ΒΟΙΩΤΙΑΣ</option><option value="9195">ΑΛΙΜΟΥ/ΑΤΤΙΚΗΣ</option><option value="9104">ΑΛΜΥΡΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9042">ΑΛΜΩΠΙΑΣ/ΠΕΛΛΗΣ</option><option value="9109">ΑΛΟΝΝΗΣΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9315">ΑΜΑΡΙΟΥ/ΡΕΘΥΜΝΗΣ</option><option value="9168">ΑΜΑΡΟΥΣΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9291">ΑΜΟΡΓΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9026">ΑΜΠΕΛΟΚΗΠΩΝ - ΜΕΝΕΜΕΝΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9070">ΑΜΥΝΤΑΙΟΥ/ΦΛΩΡΙΝΗΣ</option><option value="9158">ΑΜΦΙΚΛΕΙΑΣ - ΕΛΑΤΕΙΑΣ/ΦΘΙΩΤΙΔΟΣ</option><option value="9125">ΑΜΦΙΛΟΧΙΑΣ/ΑΙΤΩΛ/ΝΙΑΣ</option><option value="9049">ΑΜΦΙΠΟΛΗΣ/ΣΕΡΡΩΝ</option><option value="9248">ΑΝΑΤΟΛΙΚΗΣ ΜΑΝΗΣ/ΛΑΚΩΝΙΑΣ</option><option value="9269">ΑΝΑΦΗΣ/ΚΥΚΛΑΔΩΝ</option><option value="9135">ΑΝΔΡΑΒΙΔΑΣ - ΚΥΛΛΗΝΗΣ/ΗΛΕΙΑΣ</option><option value="9136">ΑΝΔΡΙΤΣΑΙΝΑΣ - ΚΡΕΣΤΕΝΩΝ/ΗΛΕΙΑΣ</option><option value="9268">ΑΝΔΡΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9293">ΑΝΤΙΠΑΡΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9316">ΑΝΩΓΕΙΩΝ/ΡΕΘΥΜΝΗΣ</option><option value="9319">ΑΠΟΚΟΡΩΝΟΥ/ΧΑΝΙΩΝ</option><option value="9091">ΑΡΓΙΘΕΑΣ/ΚΑΡΔΙΤΣΗΣ</option><option value="9233">ΑΡΓΟΥΣ - ΜΥΚΗΝΩΝ/ΑΡΓΟΛΙΔΟΣ</option><option value="9065">ΑΡΓΟΥΣ ΟΡΕΣΤΙΚΟΥ/ΚΑΣΤΟΡΙΑΣ</option><option value="9056">ΑΡΙΣΤΟΤΕΛΗ/ΧΑΛΚΙΔΙΚΗΣ</option><option value="9019">ΑΡΡΙΑΝΩΝ/ΡΟΔΟΠΗΣ</option><option value="9073">ΑΡΤΑΙΩΝ/ΑΡΤΗΣ</option><option value="9137">ΑΡΧΑΙΑΣ ΟΛΥΜΠΙΑΣ/ΗΛΕΙΑΣ</option><option value="9302">ΑΡΧΑΝΩΝ - ΑΣΤΕΡΟΥΣΙΩΝ/ΗΡΑΚΛΕΙΟΥ</option><option value="9228">ΑΣΠΡΟΠΥΡΓΟΥ/ΑΤΤΙΚΗΣ</option><option value="9275">ΑΣΤΥΠΑΛΑΙΑΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9215">ΑΧΑΡΝΩΝ/ΑΤΤΙΚΗΣ</option><option value="9216">ΒΑΡΗΣ - ΒΟΥΛΑΣ - ΒΟΥΛΙΑΓΜΕΝΗΣ/ΑΤΤΙΚΗΣ</option><option value="9242">ΒΕΛΟΥ - ΒΟΧΑΣ/ΚΟΡΙΝΘΙΑΣ</option><option value="9024">ΒΕΡΟΙΑΣ/ΗΜΑΘΙΑΣ</option><option value="9303">ΒΙΑΝΝΟΥ/ΗΡΑΚΛΕΙΟΥ</option><option value="9050">ΒΙΣΑΛΤΙΑΣ/ΣΕΡΡΩΝ</option><option value="9066">ΒΟΙΟΥ/ΚΟΖΑΝΗΣ</option><option value="9027">ΒΟΛΒΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9105">ΒΟΛΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9237">ΒΟΡΕΙΑΣ ΚΥΝΟΥΡΙΑΣ/ΑΡΚΑΔΙΑΣ</option><option value="9080">ΒΟΡΕΙΩΝ ΤΖΟΥΜΕΡΚΩΝ/ΙΩΑΝΝΙΝΩΝ</option><option value="9169">ΒΡΙΛΗΣΣΙΩΝ/ΑΤΤΙΚΗΣ</option><option value="9187">ΒΥΡΩΝΟΣ/ΑΤΤΙΚΗΣ</option><option value="9188">ΓΑΛΑΤΣΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9320">ΓΑΥΔΟΥ/ΧΑΝΙΩΝ</option><option value="9074">ΓΕΩΡΓΙΟΥ ΚΑΡΑΙΣΚΑΚΗ/ΑΡΤΗΣ</option><option value="9196">ΓΛΥΦΑΔΑΣ/ΑΤΤΙΚΗΣ</option><option value="9304">ΓΟΡΤΥΝΑΣ/ΗΡΑΚΛΕΙΟΥ</option><option value="9238">ΓΟΡΤΥΝΙΑΣ/ΑΡΚΑΔΙΑΣ</option><option value="9061">ΓΡΕΒΕΝΩΝ/ΓΡΕΒΕΝΩΝ</option><option value="9189">ΔΑΦΝΗΣ - ΥΜΗΤΤΟΥ/ΑΤΤΙΚΗΣ</option><option value="9028">ΔΕΛΤΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9165">ΔΕΛΦΩΝ/ΦΩΚΙΔΟΣ</option><option value="9062">ΔΕΣΚΑΤΗΣ/ΓΡΕΒΕΝΩΝ</option><option value="9007">ΔΙΔΥΜΟΤΕΙΧΟΥ/ΕΒΡΟΥ</option><option value="9217">ΔΙΟΝΥΣΟΥ/ΑΤΤΙΚΗΣ</option><option value="9046">ΔΙΟΥ - ΟΛΥΜΠΟΥ/ΠΙΕΡΙΑΣ</option><option value="9148">ΔΙΡΦΥΩΝ - ΜΕΣΣΑΠΙΩΝ/ΕΥΒΟΙΑΣ</option><option value="9143">ΔΙΣΤΟΜΟΥ - ΑΡΑΧΟΒΑΣ - ΑΝΤΙΚΥΡΑΣ/ΒΟΙΩΤΙΑΣ</option><option value="9159">ΔΟΜΟΚΟΥ/ΦΘΙΩΤΙΔΟΣ</option><option value="9001">ΔΟΞΑΤΟΥ/ΔΡΑΜΑΣ</option><option value="9002">ΔΡΑΜΑΣ/ΔΡΑΜΑΣ</option><option value="9131">ΔΥΤΙΚΗΣ ΑΧΑΙΑΣ/ΑΧΑΪΑΣ</option><option value="9253">ΔΥΤΙΚΗΣ ΜΑΝΗΣ/ΜΕΣΣΗΝΙΑΣ</option><option value="9081">ΔΩΔΩΝΗΣ/ΙΩΑΝΝΙΝΩΝ</option><option value="9166">ΔΩΡΙΔΟΣ/ΦΩΚΙΔΟΣ</option><option value="9043">ΕΔΕΣΣΑΣ/ΠΕΛΛΗΣ</option><option value="9098">ΕΛΑΣΣΟΝΑΣ/ΛΑΡΙΣΗΣ</option><option value="9249">ΕΛΑΦΟΝΗΣΟΥ/ΛΑΚΩΝΙΑΣ</option><option value="9229">ΕΛΕΥΣΙΝΑΣ/ΑΤΤΙΚΗΣ</option><option value="9197">ΕΛΛΗΝΙΚΟΥ - ΑΡΓΥΡΟΥΠΟΛΗΣ/ΑΤΤΙΚΗΣ</option><option value="9051">ΕΜΜΑΝΟΥΗΛ ΠΑΠΠΑ/ΣΕΡΡΩΝ</option><option value="9067">ΕΟΡΔΑΙΑΣ/ΚΟΖΑΝΗΣ</option><option value="9234">ΕΠΙΔΑΥΡΟΥ/ΑΡΓΟΛΙΔΟΣ</option><option value="9149">ΕΡΕΤΡΙΑΣ/ΕΥΒΟΙΑΣ</option><option value="9235">ΕΡΜΙΟΝΙΔΑΣ/ΑΡΓΟΛΙΔΟΣ</option><option value="9132">ΕΡΥΜΑΝΘΟΥ/ΑΧΑΪΑΣ</option><option value="9250">ΕΥΡΩΤΑ/ΛΑΚΩΝΙΑΣ</option><option value="9106">ΖΑΓΟΡΑΣ - ΜΟΥΡΕΣΙΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9082">ΖΑΓΟΡΙΟΥ/ΙΩΑΝΝΙΝΩΝ</option><option value="9116">ΖΑΚΥΝΘΟΥ/ΖΑΚΥΝΘΟΥ</option><option value="9138">ΖΑΧΑΡΩΣ/ΗΛΕΙΑΣ</option><option value="9088">ΖΗΡΟΥ/ΠΡΕΒΕΖΗΣ</option><option value="9083">ΖΙΤΣΑΣ/ΙΩΑΝΝΙΝΩΝ</option><option value="9190">ΖΩΓΡΑΦΟΥ/ΑΤΤΙΚΗΣ</option><option value="9077">ΗΓΟΥΜΕΝΙΤΣΑΣ/ΘΕΣΠΡΩΤΙΑΣ</option><option value="9139">ΗΛΙΔΑΣ/ΗΛΕΙΑΣ</option><option value="9191">ΗΛΙΟΥΠΟΛΕΩΣ/ΑΤΤΙΚΗΣ</option><option value="9052">ΗΡΑΚΛΕΙΑΣ/ΣΕΡΡΩΝ</option><option value="9170">ΗΡΑΚΛΕΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9305">ΗΡΑΚΛΕΙΟΥ/ΗΡΑΚΛΕΙΟΥ</option><option value="9281">ΗΡΩΙΚΗΣ ΝΗΣΟΥ ΚΑΣΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9267">ΗΡΩΙΚΗΣ ΝΗΣΟΥ ΨΑΡΩΝ/ΧΙΟΥ</option><option value="9025">ΗΡΩΙΚΗΣ ΠΟΛΕΩΣ ΝΑΟΥΣΑΣ/ΗΜΑΘΙΑΣ</option><option value="9011">ΘΑΣΟΥ/ΚΑΒΑΛΑΣ</option><option value="9029">ΘΕΡΜΑΙΚΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9030">ΘΕΡΜΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9126">ΘΕΡΜΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option><option value="9031">ΘΕΣΣΑΛΟΝΙΚΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9144">ΘΗΒΑΙΩΝ/ΒΟΙΩΤΙΑΣ</option><option value="9270">ΘΗΡΑΣ/ΚΥΚΛΑΔΩΝ</option><option value="9020">ΙΑΣΜΟΥ/ΡΟΔΟΠΗΣ</option><option value="9311">ΙΕΡΑΠΕΤΡΑΣ/ΛΑΣΙΘΙΟΥ</option><option value="9127">ΙΕΡΑΣ ΠΟΛΗΣ ΜΕΣΟΛΟΓΓΙΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option><option value="9271">ΙΗΤΩΝ/ΚΥΚΛΑΔΩΝ</option><option value="9117">ΙΘΑΚΗΣ/ΚΕΦΑΛΛΗΝΙΑΣ</option><option value="9259">ΙΚΑΡΙΑΣ /ΣΑΜΟΥ</option><option value="9182">ΙΛΙΟΥ (ΝΕΩΝ ΛΙΟΣΙΩΝ)/ΑΤΤΙΚΗΣ</option><option value="9150">ΙΣΤΙΑΙΑΣ - ΑΙΔΗΨΟΥ/ΕΥΒΟΙΑΣ</option><option value="9084">ΙΩΑΝΝΙΤΩΝ/ΙΩΑΝΝΙΝΩΝ</option><option value="9012">ΚΑΒΑΛΑΣ/ΚΑΒΑΛΑΣ</option><option value="9192">ΚΑΙΣΑΡΙΑΝΗΣ/ΑΤΤΙΚΗΣ</option><option value="9133">ΚΑΛΑΒΡΥΤΩΝ/ΑΧΑΪΑΣ</option><option value="9032">ΚΑΛΑΜΑΡΙΑΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9254">ΚΑΛΑΜΑΤΑΣ/ΜΕΣΣΗΝΙΑΣ</option><option value="9198">ΚΑΛΛΙΘΕΑΣ/ΑΤΤΙΚΗΣ</option><option value="9276">ΚΑΛΥΜΝΙΩΝ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9163">ΚΑΜΕΝΩΝ ΒΟΥΡΛΩΝ/ΦΘΙΩΤΙΔΟΣ</option><option value="9321">ΚΑΝΤΑΝΟΥ - ΣΕΛΙΝΟΥ/ΧΑΝΙΩΝ</option><option value="9092">ΚΑΡΔΙΤΣΑΣ/ΚΑΡΔΙΤΣΗΣ</option><option value="9280">ΚΑΡΠΑΘΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9157">ΚΑΡΠΕΝΗΣΙΟΥ/ΕΥΡΥΤΑΝΙΑΣ</option><option value="9151">ΚΑΡΥΣΤΟΥ/ΕΥΒΟΙΑΣ</option><option value="9057">ΚΑΣΣΑΝΔΡΑΣ/ΧΑΛΚΙΔΙΚΗΣ</option><option value="9063">ΚΑΣΤΟΡΙΑΣ/ΚΑΣΤΟΡΙΑΣ</option><option value="9047">ΚΑΤΕΡΙΝΗΣ/ΠΙΕΡΙΑΣ</option><option value="9003">ΚΑΤΩ ΝΕΥΡΟΚΟΠΙΟΥ/ΔΡΑΜΑΣ</option><option value="9282">ΚΕΑΣ/ΚΥΚΛΑΔΩΝ</option><option value="9075">ΚΕΝΤΡΙΚΩΝ ΤΖΟΥΜΕΡΚΩΝ /ΑΡΤΗΣ</option><option value="9202">ΚΕΡΑΤΣΙΝΙΟΥ - ΔΡΑΠΕΤΣΩΝΑΣ/ΑΤΤΙΚΗΣ</option><option value="9118">ΚΕΡΚΥΡΑΣ/ΚΕΡΚΥΡΑΣ</option><option value="9120">ΚΕΦΑΛΟΝΙΑΣ/ΚΕΦΑΛΛΗΝΙΑΣ</option><option value="9171">ΚΗΦΙΣΙΑΣ/ΑΤΤΙΚΗΣ</option><option value="9099">ΚΙΛΕΛΕΡ/ΛΑΡΙΣΗΣ</option><option value="9040">ΚΙΛΚΙΣ/ΚΙΛΚΙΣ</option><option value="9286">ΚΙΜΩΛΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9322">ΚΙΣΣΑΜΟΥ/ΧΑΝΙΩΝ</option><option value="9068">ΚΟΖΑΝΗΣ/ΚΟΖΑΝΗΣ</option><option value="9021">ΚΟΜΟΤΗΝΗΣ/ΡΟΔΟΠΗΣ</option><option value="9085">ΚΟΝΙΤΣΑΣ/ΙΩΑΝΝΙΝΩΝ</option><option value="9033">ΚΟΡΔΕΛΙΟΥ -ΕΥΟΣΜΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9243">ΚΟΡΙΝΘΙΩΝ/ΚΟΡΙΝΘΙΑΣ</option><option value="9203">ΚΟΡΥΔΑΛΛΟΥ/ΑΤΤΙΚΗΣ</option><option value="9218">ΚΡΩΠΙΑΣ/ΑΤΤΙΚΗΣ</option><option value="9209">ΚΥΘΗΡΩΝ/ΑΤΤΙΚΗΣ</option><option value="9283">ΚΥΘΝΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9152">ΚΥΜΗΣ - ΑΛΙΒΕΡΙΟΥ/ΕΥΒΟΙΑΣ</option><option value="9284">ΚΩ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9034">ΛΑΓΚΑΔΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9160">ΛΑΜΙΕΩΝ/ΦΘΙΩΤΙΔΟΣ</option><option value="9100">ΛΑΡΙΣΑΙΩΝ/ΛΑΡΙΣΗΣ</option><option value="9219">ΛΑΥΡΕΩΤΙΚΗΣ/ΑΤΤΙΚΗΣ</option><option value="9145">ΛΕΒΑΔΕΩΝ/ΒΟΙΩΤΙΑΣ</option><option value="9277">ΛΕΙΨΩΝ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9278">ΛΕΡΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9261">ΛΕΣΒΟΥ/ΛΕΣΒΟΥ</option><option value="9121">ΛΕΥΚΑΔΑΣ/ΛΕΥΚΑΔΟΣ</option><option value="9263">ΛΗΜΝΟΥ/ΛΕΣΒΟΥ</option><option value="9093">ΛΙΜΝΗΣ ΠΛΑΣΤΗΡΑ/ΚΑΡΔΙΤΣΗΣ</option><option value="9161">ΛΟΚΡΩΝ/ΦΘΙΩΤΙΔΟΣ</option><option value="9244">ΛΟΥΤΡΑΚΙΟΥ-ΠΕΡΑΧΩΡΑΣ-ΑΓΙΩΝ ΘΕΟΔΩΡΩΝ/ΚΟΡΙΝΘΙΑΣ</option><option value="9172">ΛΥΚΟΒΡΥΣΗΣ - ΠΕΥΚΗΣ/ΑΤΤΙΚΗΣ</option><option value="9162">ΜΑΚΡΑΚΩΜΗΣ/ΦΘΙΩΤΙΔΟΣ</option><option value="9306">ΜΑΛΕΒΙΖΙΟΥ/ΗΡΑΚΛΕΙΟΥ</option><option value="9230">ΜΑΝΔΡΑΣ - ΕΙΔΥΛΛΙΑΣ/ΑΤΤΙΚΗΣ</option><option value="9153">ΜΑΝΤΟΥΔΙΟΥ - ΛΙΜΝΗΣ - ΑΓΙΑΣ ΑΝΝΑΣ/ΕΥΒΟΙΑΣ</option><option value="9220">ΜΑΡΑΘΩΝΟΣ/ΑΤΤΙΚΗΣ</option><option value="9221">ΜΑΡΚΟΠΟΥΛΟΥ ΜΕΣΟΓΑΙΑΣ/ΑΤΤΙΚΗΣ</option><option value="9022">ΜΑΡΩΝΕΙΑΣ - ΣΑΠΩΝ/ΡΟΔΟΠΗΣ</option><option value="9239">ΜΕΓΑΛΟΠΟΛΗΣ/ΑΡΚΑΔΙΑΣ</option><option value="9122">ΜΕΓΑΝΗΣΙΟΥ/ΛΕΥΚΑΔΟΣ</option><option value="9231">ΜΕΓΑΡΕΩΝ/ΑΤΤΙΚΗΣ</option><option value="9295">ΜΕΓΙΣΤΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9255">ΜΕΣΣΗΝΗΣ/ΜΕΣΣΗΝΙΑΣ</option><option value="9173">ΜΕΤΑΜΟΡΦΩΣΕΩΣ/ΑΤΤΙΚΗΣ</option><option value="9112">ΜΕΤΕΩΡΩΝ/ΤΡΙΚΑΛΩΝ</option><option value="9086">ΜΕΤΣΟΒΟΥ/ΙΩΑΝΝΙΝΩΝ</option><option value="9287">ΜΗΛΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9307">ΜΙΝΩΑ ΠΕΔΙΑΔΟΣ/ΗΡΑΚΛΕΙΟΥ</option><option value="9251">ΜΟΝΕΜΒΑΣΙΑΣ/ΛΑΚΩΝΙΑΣ</option><option value="9199">ΜΟΣΧΑΤΟΥ - ΤΑΥΡΟΥ/ΑΤΤΙΚΗΣ</option><option value="9094">ΜΟΥΖΑΚΙΟΥ/ΚΑΡΔΙΤΣΗΣ</option><option value="9016">ΜΥΚΗΣ/ΞΑΝΘΗΣ</option><option value="9290">ΜΥΚΟΝΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9317">ΜΥΛΟΠΟΤΑΜΟΥ/ΡΕΘΥΜΝΗΣ</option><option value="9292">ΝΑΞΟΥ &amp; ΜΙΚΡΩΝ ΚΥΚΛΑΔΩΝ/ΚΥΚΛΑΔΩΝ</option><option value="9128">ΝΑΥΠΑΚΤΙΑΣ/ΑΙΤΩΛ/ΝΙΑΣ</option><option value="9236">ΝΑΥΠΛΙΕΩΝ/ΑΡΓΟΛΙΔΟΣ</option><option value="9035">ΝΕΑΠΟΛΗΣ - ΣΥΚΕΩΝ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9053">ΝΕΑΣ ΖΙΧΝΗΣ/ΣΕΡΡΩΝ</option><option value="9174">ΝΕΑΣ ΙΩΝΙΑΣ/ΑΤΤΙΚΗΣ</option><option value="9058">ΝΕΑΣ ΠΡΟΠΟΝΤΙΔΑΣ/ΧΑΛΚΙΔΙΚΗΣ</option><option value="9200">ΝΕΑΣ ΣΜΥΡΝΗΣ/ΑΤΤΙΚΗΣ</option><option value="9193">ΝΕΑΣ ΦΙΛΑΔΕΛΦΕΙΑΣ - ΝΕΑΣ ΧΑΛΚΗΔΟΝΑΣ/ΑΤΤΙΚΗΣ</option><option value="9245">ΝΕΜΕΑΣ/ΚΟΡΙΝΘΙΑΣ</option><option value="9064">ΝΕΣΤΟΡΙΟΥ/ΚΑΣΤΟΡΙΑΣ</option><option value="9013">ΝΕΣΤΟΥ/ΚΑΒΑΛΑΣ</option><option value="9204">ΝΙΚΑΙΑΣ - ΑΓΙΟΥ ΙΩΑΝΝΗ ΡΕΝΤΗ/ΑΤΤΙΚΗΣ</option><option value="9076">ΝΙΚΟΛΑΟΥ ΣΚΟΥΦΑ/ΑΡΤΗΣ</option><option value="9285">ΝΙΣΥΡΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9240">ΝΟΤΙΑΣ ΚΥΝΟΥΡΙΑΣ/ΑΡΚΑΔΙΑΣ</option><option value="9107">ΝΟΤΙΟΥ ΠΗΛΙΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9017">ΞΑΝΘΗΣ/ΞΑΝΘΗΣ</option><option value="9129">ΞΗΡΟΜΕΡΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option><option value="9246">ΞΥΛΟΚΑΣΤΡΟΥ - ΕΥΡΩΣΤΙΝΗΣ/ΚΟΡΙΝΘΙΑΣ</option><option value="9265">ΟΙΝΟΥΣΣΩΝ/ΧΙΟΥ</option><option value="9256">ΟΙΧΑΛΙΑΣ/ΜΕΣΣΗΝΙΑΣ</option><option value="9008">ΟΡΕΣΤΙΑΔΑΣ/ΕΒΡΟΥ</option><option value="9312">ΟΡΟΠΕΔΙΟΥ ΛΑΣΙΘΙΟΥ/ΛΑΣΙΘΙΟΥ</option><option value="9146">ΟΡΧΟΜΕΝΟΥ/ΒΟΙΩΤΙΑΣ</option><option value="9014">ΠΑΓΓΑΙΟΥ/ΚΑΒΑΛΑΣ</option><option value="9222">ΠΑΙΑΝΙΑΣ/ΑΤΤΙΚΗΣ</option><option value="9041">ΠΑΙΟΝΙΑΣ/ΚΙΛΚΙΣ</option><option value="9201">ΠΑΛΑΙΟΥ ΦΑΛΗΡΟΥ/ΑΤΤΙΚΗΣ</option><option value="9095">ΠΑΛΑΜΑ/ΚΑΡΔΙΤΣΗΣ</option><option value="9223">ΠΑΛΛΗΝΗΣ/ΑΤΤΙΚΗΣ</option><option value="9119">ΠΑΞΩΝ/ΚΕΡΚΥΡΑΣ</option><option value="9175">ΠΑΠΑΓΟΥ - ΧΟΛΑΡΓΟΥ/ΑΤΤΙΚΗΣ</option><option value="9004">ΠΑΡΑΝΕΣΤΙΟΥ/ΔΡΑΜΑΣ</option><option value="9089">ΠΑΡΓΑΣ/ΠΡΕΒΕΖΗΣ</option><option value="9294">ΠΑΡΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9279">ΠΑΤΜΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9134">ΠΑΤΡΕΩΝ/ΑΧΑΪΑΣ</option><option value="9036">ΠΑΥΛΟΥ ΜΕΛΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9205">ΠΕΙΡΑΙΩΣ/ΑΤΤΙΚΗΣ</option><option value="9044">ΠΕΛΛΑΣ/ΠΕΛΛΗΣ</option><option value="9176">ΠΕΝΤΕΛΗΣ/ΑΤΤΙΚΗΣ</option><option value="9206">ΠΕΡΑΜΑΤΟΣ/ΑΤΤΙΚΗΣ</option><option value="9183">ΠΕΡΙΣΤΕΡΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9184">ΠΕΤΡΟΥΠΟΛΕΩΣ/ΑΤΤΙΚΗΣ</option><option value="9140">ΠΗΝΕΙΟΥ/ΗΛΕΙΑΣ</option><option value="9323">ΠΛΑΤΑΝΙΑ/ΧΑΝΙΩΝ</option><option value="9059">ΠΟΛΥΓΥΡΟΥ/ΧΑΛΚΙΔΙΚΗΣ</option><option value="9210">ΠΟΡΟΥ/ΑΤΤΙΚΗΣ</option><option value="9090">ΠΡΕΒΕΖΑΣ/ΠΡΕΒΕΖΗΣ</option><option value="9071">ΠΡΕΣΠΩΝ/ΦΛΩΡΙΝΗΣ</option><option value="9005">ΠΡΟΣΟΤΣΑΝΗΣ/ΔΡΑΜΑΣ</option><option value="9048">ΠΥΔΝΑΣ - ΚΟΛΙΝΔΡΟΥ/ΠΙΕΡΙΑΣ</option><option value="9037">ΠΥΛΑΙΑΣ - ΧΟΡΤΙΑΤΗ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9113">ΠΥΛΗΣ/ΤΡΙΚΑΛΩΝ</option><option value="9257">ΠΥΛΟΥ - ΝΕΣΤΟΡΟΣ/ΜΕΣΣΗΝΙΑΣ</option><option value="9141">ΠΥΡΓΟΥ/ΗΛΕΙΑΣ</option><option value="9087">ΠΩΓΩΝΙΟΥ/ΙΩΑΝΝΙΝΩΝ</option><option value="9224">ΡΑΦΗΝΑΣ - ΠΙΚΕΡΜΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9318">ΡΕΘΥΜΝΗΣ/ΡΕΘΥΜΝΗΣ</option><option value="9108">ΡΗΓΑ ΦΕΡΑΙΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9296">ΡΟΔΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9211">ΣΑΛΑΜΙΝΑΣ/ΑΤΤΙΚΗΣ</option><option value="9009">ΣΑΜΟΘΡΑΚΗΣ/ΕΒΡΟΥ</option><option value="9264">ΣΑΜΟΥ/ΣΑΜΟΥ</option><option value="9225">ΣΑΡΩΝΙΚΟΥ/ΑΤΤΙΚΗΣ</option><option value="9069">ΣΕΡΒΙΩΝ - ΒΕΛΒΕΝΤΟΥ /ΚΟΖΑΝΗΣ</option><option value="9288">ΣΕΡΙΦΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9054">ΣΕΡΡΩΝ/ΣΕΡΡΩΝ</option><option value="9313">ΣΗΤΕΙΑΣ/ΛΑΣΙΘΙΟΥ</option><option value="9060">ΣΙΘΩΝΙΑΣ/ΧΑΛΚΙΔΙΚΗΣ</option><option value="9272">ΣΙΚΙΝΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9247">ΣΙΚΥΩΝΙΩΝ/ΚΟΡΙΝΘΙΑΣ</option><option value="9055">ΣΙΝΤΙΚΗΣ/ΣΕΡΡΩΝ</option><option value="9289">ΣΙΦΝΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9110">ΣΚΙΑΘΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9111">ΣΚΟΠΕΛΟΥ/ΜΑΓΝΗΣΙΑΣ</option><option value="9045">ΣΚΥΔΡΑΣ/ΠΕΛΛΗΣ</option><option value="9154">ΣΚΥΡΟΥ/ΕΥΒΟΙΑΣ</option><option value="9078">ΣΟΥΛΙΟΥ/ΘΕΣΠΡΩΤΙΑΣ</option><option value="9010">ΣΟΥΦΛΙΟΥ/ΕΒΡΟΥ</option><option value="9096">ΣΟΦΑΔΩΝ/ΚΑΡΔΙΤΣΗΣ</option><option value="9252">ΣΠΑΡΤΗΣ/ΛΑΚΩΝΙΑΣ</option><option value="9226">ΣΠΑΤΩΝ - ΑΡΤΕΜΙΔΟΣ/ΑΤΤΙΚΗΣ</option><option value="9212">ΣΠΕΤΣΩΝ/ΑΤΤΙΚΗΣ</option><option value="9164">ΣΤΥΛΙΔΑΣ/ΦΘΙΩΤΙΔΟΣ</option><option value="9297">ΣΥΜΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9300">ΣΥΡΟΥ - ΕΡΜΟΥΠΟΛΗΣ/ΚΥΚΛΑΔΩΝ</option><option value="9324">ΣΦΑΚΙΩΝ/ΧΑΝΙΩΝ</option><option value="9147">ΤΑΝΑΓΡΑΣ/ΒΟΙΩΤΙΑΣ</option><option value="9101">ΤΕΜΠΩΝ /ΛΑΡΙΣΗΣ</option><option value="9298">ΤΗΛΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9301">ΤΗΝΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9018">ΤΟΠΕΙΡΟΥ/ΞΑΝΘΗΣ</option><option value="9114">ΤΡΙΚΚΑΙΩΝ/ΤΡΙΚΑΛΩΝ</option><option value="9241">ΤΡΙΠΟΛΗΣ/ΑΡΚΑΔΙΑΣ</option><option value="9258">ΤΡΙΦΥΛΛΙΑΣ/ΜΕΣΣΗΝΙΑΣ</option><option value="9213">ΤΡΟΙΖΗΝΙΑΣ-ΜΕΘΑΝΩΝ/ΑΤΤΙΚΗΣ</option><option value="9102">ΤΥΡΝΑΒΟΥ/ΛΑΡΙΣΗΣ</option><option value="9214">ΥΔΡΑΣ/ΑΤΤΙΚΗΣ</option><option value="9308">ΦΑΙΣΤΟΥ/ΗΡΑΚΛΕΙΟΥ</option><option value="9115">ΦΑΡΚΑΔΟΝΑΣ/ΤΡΙΚΑΛΩΝ</option><option value="9103">ΦΑΡΣΑΛΩΝ/ΛΑΡΙΣΗΣ</option><option value="9079">ΦΙΛΙΑΤΩΝ/ΘΕΣΠΡΩΤΙΑΣ</option><option value="9177">ΦΙΛΟΘΕΗΣ - ΨΥΧΙΚΟΥ/ΑΤΤΙΚΗΣ</option><option value="9072">ΦΛΩΡΙΝΑΣ/ΦΛΩΡΙΝΗΣ</option><option value="9273">ΦΟΛΕΓΑΝΔΡΟΥ/ΚΥΚΛΑΔΩΝ</option><option value="9260">ΦΟΥΡΝΩΝ ΚΟΡΣΕΩΝ/ΣΑΜΟΥ</option><option value="9232">ΦΥΛΗΣ/ΑΤΤΙΚΗΣ</option><option value="9185">ΧΑΙΔΑΡΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9178">ΧΑΛΑΝΔΡΙΟΥ/ΑΤΤΙΚΗΣ</option><option value="9038">ΧΑΛΚΗΔΟΝΟΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9299">ΧΑΛΚΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option><option value="9155">ΧΑΛΚΙΔΕΩΝ/ΕΥΒΟΙΑΣ</option><option value="9325">ΧΑΝΙΩΝ/ΧΑΝΙΩΝ</option><option value="9309">ΧΕΡΣΟΝΗΣΟΥ/ΗΡΑΚΛΕΙΟΥ</option><option value="9266">ΧΙΟΥ/ΧΙΟΥ</option><option value="9039">ΩΡΑΙΟΚΑΣΤΡΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option><option value="9227">ΩΡΩΠΟΥ/ΑΤΤΙΚΗΣ</option></select>
                            <?php if ($errors->has('municipality')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('municipality'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <button class="btn btn-block btn-primary mt-4" type="submit">Αποθήκευση Αλλαγών</button>
                </form>
            </div>
        </div>   
    </div>
</div>
<!--
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('#sex').val("<?php echo e(Auth::user()->sex); ?>");
        $('#municipality option[value=<?php echo e(Auth::user()->municipality); ?>]').attr('selected','selected');
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\election-mng\resources\views/eterodimotes.blade.php ENDPATH**/ ?>