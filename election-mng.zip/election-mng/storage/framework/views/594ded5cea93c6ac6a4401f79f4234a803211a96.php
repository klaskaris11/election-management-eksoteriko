<?php $__env->startSection('page-name'); ?>
    Home Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12">
        <!-- START card-->
        <div class="card card-default">
            <div class="card-header border-bottom">          
                <a class="float-right fa-110x">
                    <em class="fas fa-table"></em>
                </a>
                <div class="card-title">
                     <h4 class="mb-0">Ιστορικό Αιτημάτων</h4>
                </div>
            </div>
            <div class="card-body">
                <!-- START table-responsive-->
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Username</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Mark</td>
                                <td>Otto</td>
                                <td>@mdo</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Jacob</td>
                                <td>Thornton</td>
                                <td>@fat</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Larry</td>
                                <td>the Bird</td>
                                <td>@twitter</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <!-- END table-responsive-->
            </div>
        </div>
        <!-- END card-->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\election-mng\resources\views/home.blade.php ENDPATH**/ ?>