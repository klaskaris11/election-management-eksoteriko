<?php $__env->startSection('content'); ?>

<div class="block-center mt-4 wd-xl">
    <!-- START card-->
    <div class="card card-flat">
        <div class="card-header text-center bg-dark">
            <a href="#">
                <img class="block-center" src="<?php echo e(asset('img/logo-relog-transparent.png')); ?>" alt="Image">
            </a>
        </div>
        <div class="card-body">
            <h4 class="text-center py-2">Είσοδος Χρήστη</h4>

            <div class="alert alert-warning alert-dismissible fade show" id="warningBox" role="alert" style="display:none">
                <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <strong>WARNING:</strong> Ο λογιαριασμός δεν έχει ενεργοποιηθεί. Προσπαθήστε ξανά σε λίγη ώρα.
            </div>

          <form class="mb-3" method="POST" action="<?php echo e(route('login')); ?>" id="loginForm" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="identity_num">Αριθμός Παραστατικού</label>
                <input class="form-control <?php if ($errors->has('identity_num')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_num'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="identity_num" id="identity_num" type="text" placeholder="Αριθμός.." value="<?php echo e(old('identity_num')); ?>" required autocomplete="identity_num" autofocus>
                <?php if ($errors->has('identity_num')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_num'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group">
                <label for="password">Κωδικός</label>
                <input class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" id="password" type="password" placeholder="Κωδικός.." autocomplete="off" required>
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="clearfix">
                <div class="form-group row">
                    <div class="col-md-6 offset-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="remember">
                                <?php echo e(__('Remember Me')); ?>

                            </label>
                        </div>
                    </div>
                </div>                 
            </div>
            <button class="btn btn-block btn-primary mt-3" type="submit">Είσοδος</button>
        </form>
        <p class="pt-3 text-center">Need to Signup?</p>
        <a class="btn btn-block btn-secondary" href="<?php echo e(route('register')); ?>">Register Now</a>
    </div>
</div>
<!-- END card-->
<div class="p-3 text-center">
    <span class="mr-2">&copy;</span>
    <span>2019</span>
    <span class="mr-2">-</span>
    <span>Election Management</span>
    <br>
    <span>itp17405 - itp - itp</span>
</div>
</div>

<!--
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Login')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="identity_num" class="col-md-4 col-form-label text-md-right"><?php echo e(__('# Παραστατικού')); ?></label>

                            <div class="col-md-6">
                                <input id="identity_num" type="text" class="form-control <?php if ($errors->has('identity_num')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_num'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="identity_num" value="<?php echo e(old('identity_num')); ?>" required autocomplete="identity_num" autofocus>

                                <?php if ($errors->has('identity_num')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_num'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $( "#loginForm" ).submit(function( event ) {         
        event.preventDefault();
        let identity = $('#identity_num').val();
        console.log(identity)
        $.ajax({
            method: 'GET',
            url: 'http://127.0.0.1:8000/test/' + identity
        }).done(function(is_enabled){   
            if(is_enabled == 1){        //0 for disabled, 1 for enabled
                $("#loginForm")[0].submit();
            }else{
                $('#warningBox').css('display', 'block');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.first-screen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\election-mng\resources\views/auth/login.blade.php ENDPATH**/ ?>