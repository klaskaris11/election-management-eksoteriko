<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('firstname')->collation('utf8_general_ci');
            $table->string('lastname')->collation('utf8_general_ci');
            $table->string('email')->collation('utf8_general_ci');
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password')->collation('utf8_general_ci');            
            $table->string('address')->collation('utf8_general_ci');
            $table->string('address_num')->collation('utf8_general_ci');
            $table->string('identity_kind')->collation('utf8_general_ci');
            $table->string('identity_num')->unique();
            $table->string('identity_document', 256)->collation('utf8_general_ci');
            $table->string('bank')->collation('utf8_general_ci');
            $table->string('iban')->collation('utf8_general_ci');
            $table->string('sex')->collation('utf8_general_ci');
            $table->string('phone', 10);
            $table->string('municipality')->collation('utf8_general_ci');
            $table->date('birthdate');
            $table->integer('status')->default(0);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
