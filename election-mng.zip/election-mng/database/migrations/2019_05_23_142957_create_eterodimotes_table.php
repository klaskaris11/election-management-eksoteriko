<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEterodimotesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('eterodimotes', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id'); 
            $table->Integer('user_id')->unsigned();
            $table->index('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->string('municipality')->collation('utf8_general_ci');
            $table->string('city')->collation('utf8_general_ci');      
            $table->string('address')->collation('utf8_general_ci');
            $table->string('address_num')->collation('utf8_general_ci');
            $table->string('phone', 10);
            $table->string('zip', 5);
            $table->string('deko_document', 256);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('eterodimotes');
    }
}
