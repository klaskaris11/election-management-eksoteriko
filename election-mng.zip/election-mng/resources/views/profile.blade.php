@extends('layouts.mainapp')
@section('page-name')
Επεξεργασία Προφίλ
@endsection
@section('content')
@include('inc.messages')
<div class="row">
    <div class="col-lg-12">
        <!-- START card-->
        <div class="card card-default">
            <div class="card-header border-bottom">
                <div class="card-title">
                   <h4 class="mb-0">Επεξεργασία Προφιλ</h4>
               </div>
           </div>
           <div class="card-body">
            <h4 class="text-center py-2"><i class="fas fa-user-cog fa-4x"></i></h4>
            <form class="mb-3" method="POST" id="updateForm" action="/api/users/{{Auth::user()->id}}" novalidate>
                @csrf
                {{ method_field('PATCH') }}
                <div class="form-row">
                    <div class="col-lg-6 mt-2">
                        <label for="firstname">Όνομα <span class="text-warning text-bold">(*)</span></label>
                        <input class="form-control @error('firstname') is-invalid @enderror" name="firstname" id="firstname" type="text" placeholder="Όνομα.." autocomplete="off" value="{{ Auth::user()->firstname }}" required>
                        @error('firstname')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <div class="col-lg-6 mt-2">
                        <label for="lastname">Επίθετο <span class="text-warning text-bold">(*)</span></label>
                        <input class="form-control @error('lastname') is-invalid @enderror" name="lastname" id="lastname" type="text" placeholder="Επίθετο.." autocomplete="off" value="{{ Auth::user()->lastname }}" required>
                        @error('lastname')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                        <!--<div class="col-lg-4 mt-2">
                            <label for="password">Κωδικός <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control @error('password') is-invalid @enderror" name="password" id="password" type="password" placeholder="Κωδικός.." autocomplete="off" required>
                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>-->
                    </div>

                    <div class="form-row mt-1">
                        <div class="col-lg-6 mt-2">
                            <label for="email">Email <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control @error('email') is-invalid @enderror" name="email" id="email" type="email" placeholder="Email.." autocomplete="off" value="{{ Auth::user()->email }}" required>
                            @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="col-lg-4 mt-2">
                            <label for="address">Διεύθυνση <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control @error('address') is-invalid @enderror" name="address" id="address" type="text" placeholder="Διεύθυνση.." autocomplete="off" value="{{ Auth::user()->address }}" required>
                            @error('address')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="col-lg-2 mt-2">
                            <label for="address_num">Αριθμός <span class="text-warning text-bold">(*)</span></label>
                            <input class="form-control @error('address_num') is-invalid @enderror" name="address_num" id="address_num" type="text" placeholder="Αριθμός.." autocomplete="off" value="{{ Auth::user()->address_num }}" required>
                            @error('address_num')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>

                    <div class="form-row mt-1">
                       <div class="col-lg-4 mt-2">
                        <label for="sex">Φύλλο <span class="text-warning text-bold">(*)</span></label>
                        <select class="custom-select @error('sex') is-invalid @enderror" name="sex" id="sex" required>
                            <option value="" selected>-- Επιλογή --</option>
                            <option value="Άνδρας">Άνδρας</option>
                            <option value="Γυναίκα">Γυναίκα</option>
                        </select>
                        @error('sex')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <div class="col-lg-4 mt-2">
                        <label for="phone">Τηλέφωνο <span class="text-warning text-bold">(*)</span></label>
                        <input class="form-control @error('phone') is-invalid @enderror" value="{{ Auth::user()->phone }}" maxlength="10" name="phone" id="phone" type="text" placeholder="Τηλέφωνο.." autocomplete="off" required>
                        @error('phone')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <div class="col-lg-4 mt-2">
                        <label for="municipality">Δημότης <span class="text-warning text-bold">(*)</span></label>
                        <select class="custom-select @error('municipality') is-invalid @enderror" id="municipality" name="municipality" required>
                            <option value=''>-- Επιλέξτε Δήμο --</option>
                            <option value='ΑΒΔΗΡΩΝ/ΞΑΝΘΗΣ'>ΑΒΔΗΡΩΝ/ΞΑΝΘΗΣ</option>
                            <option value='ΑΓΑΘΟΝΗΣΙΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΑΓΑΘΟΝΗΣΙΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΑΓΙΑΣ/ΛΑΡΙΣΗΣ'>ΑΓΙΑΣ/ΛΑΡΙΣΗΣ</option>
                            <option value='ΑΓΙΑΣ ΒΑΡΒΑΡΑΣ/ΑΤΤΙΚΗΣ'>ΑΓΙΑΣ ΒΑΡΒΑΡΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΓΙΑΣ ΠΑΡΑΣΚΕΥΗΣ/ΑΤΤΙΚΗΣ'>ΑΓΙΑΣ ΠΑΡΑΣΚΕΥΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΓΙΟΥ ΒΑΣΙΛΕΙΟΥ/ΡΕΘΥΜΝΗΣ'>ΑΓΙΟΥ ΒΑΣΙΛΕΙΟΥ/ΡΕΘΥΜΝΗΣ</option>
                            <option value='ΑΓΙΟΥ ΔΗΜΗΤΡΙΟΥ/ΑΤΤΙΚΗΣ'>ΑΓΙΟΥ ΔΗΜΗΤΡΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΓΙΟΥ ΕΥΣΤΡΑΤΙΟΥ/ΛΕΣΒΟΥ'>ΑΓΙΟΥ ΕΥΣΤΡΑΤΙΟΥ/ΛΕΣΒΟΥ</option>
                            <option value='ΑΓΙΟΥ ΝΙΚΟΛΑΟΥ/ΛΑΣΙΘΙΟΥ'>ΑΓΙΟΥ ΝΙΚΟΛΑΟΥ/ΛΑΣΙΘΙΟΥ</option>
                            <option value='ΑΓΙΩΝ ΑΝΑΡΓΥΡΩΝ - ΚΑΜΑΤΕΡΟΥ/ΑΤΤΙΚΗΣ'>ΑΓΙΩΝ ΑΝΑΡΓΥΡΩΝ - ΚΑΜΑΤΕΡΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΓΚΙΣΤΡΙΟΥ/ΑΤΤΙΚΗΣ'>ΑΓΚΙΣΤΡΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΓΡΑΦΩΝ/ΕΥΡΥΤΑΝΙΑΣ'>ΑΓΡΑΦΩΝ/ΕΥΡΥΤΑΝΙΑΣ</option>
                            <option value='ΑΓΡΙΝΙΟΥ/ΑΙΤΩΛ/ΝΙΑΣ'>ΑΓΡΙΝΙΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option>
                            <option value='ΑΘΗΝΑΙΩΝ/ΑΤΤΙΚΗΣ'>ΑΘΗΝΑΙΩΝ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΙΓΑΛΕΩ/ΑΤΤΙΚΗΣ'>ΑΙΓΑΛΕΩ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΙΓΙΑΛΕΙΑΣ/ΑΧΑΪΑΣ'>ΑΙΓΙΑΛΕΙΑΣ/ΑΧΑΪΑΣ</option>
                            <option value='ΑΙΓΙΝΑΣ/ΑΤΤΙΚΗΣ'>ΑΙΓΙΝΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΚΤΙΟΥ - ΒΟΝΙΤΣΑΣ/ΑΙΤΩΛ/ΝΙΑΣ'>ΑΚΤΙΟΥ - ΒΟΝΙΤΣΑΣ/ΑΙΤΩΛ/ΝΙΑΣ</option>
                            <option value='ΑΛΕΞΑΝΔΡΕΙΑΣ/ΗΜΑΘΙΑΣ'>ΑΛΕΞΑΝΔΡΕΙΑΣ/ΗΜΑΘΙΑΣ</option>
                            <option value='ΑΛΕΞΑΝΔΡΟΥΠΟΛΗΣ/ΕΒΡΟΥ'>ΑΛΕΞΑΝΔΡΟΥΠΟΛΗΣ/ΕΒΡΟΥ</option>
                            <option value='ΑΛΙΑΡΤΟΥ/ΒΟΙΩΤΙΑΣ'>ΑΛΙΑΡΤΟΥ/ΒΟΙΩΤΙΑΣ</option>
                            <option value='ΑΛΙΜΟΥ/ΑΤΤΙΚΗΣ'>ΑΛΙΜΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΛΜΥΡΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΑΛΜΥΡΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΑΛΜΩΠΙΑΣ/ΠΕΛΛΗΣ'>ΑΛΜΩΠΙΑΣ/ΠΕΛΛΗΣ</option>
                            <option value='ΑΛΟΝΝΗΣΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΑΛΟΝΝΗΣΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΑΜΑΡΙΟΥ/ΡΕΘΥΜΝΗΣ'>ΑΜΑΡΙΟΥ/ΡΕΘΥΜΝΗΣ</option>
                            <option value='ΑΜΑΡΟΥΣΙΟΥ/ΑΤΤΙΚΗΣ'>ΑΜΑΡΟΥΣΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΜΟΡΓΟΥ/ΚΥΚΛΑΔΩΝ'>ΑΜΟΡΓΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΑΜΠΕΛΟΚΗΠΩΝ - ΜΕΝΕΜΕΝΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΑΜΠΕΛΟΚΗΠΩΝ - ΜΕΝΕΜΕΝΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΑΜΥΝΤΑΙΟΥ/ΦΛΩΡΙΝΗΣ'>ΑΜΥΝΤΑΙΟΥ/ΦΛΩΡΙΝΗΣ</option>
                            <option value='ΑΜΦΙΚΛΕΙΑΣ - ΕΛΑΤΕΙΑΣ/ΦΘΙΩΤΙΔΟΣ'>ΑΜΦΙΚΛΕΙΑΣ - ΕΛΑΤΕΙΑΣ/ΦΘΙΩΤΙΔΟΣ</option>
                            <option value='ΑΜΦΙΛΟΧΙΑΣ/ΑΙΤΩΛ/ΝΙΑΣ'>ΑΜΦΙΛΟΧΙΑΣ/ΑΙΤΩΛ/ΝΙΑΣ</option>
                            <option value='ΑΜΦΙΠΟΛΗΣ/ΣΕΡΡΩΝ'>ΑΜΦΙΠΟΛΗΣ/ΣΕΡΡΩΝ</option>
                            <option value='ΑΝΑΤΟΛΙΚΗΣ ΜΑΝΗΣ/ΛΑΚΩΝΙΑΣ'>ΑΝΑΤΟΛΙΚΗΣ ΜΑΝΗΣ/ΛΑΚΩΝΙΑΣ</option>
                            <option value='ΑΝΑΦΗΣ/ΚΥΚΛΑΔΩΝ'>ΑΝΑΦΗΣ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΑΝΔΡΑΒΙΔΑΣ - ΚΥΛΛΗΝΗΣ/ΗΛΕΙΑΣ'>ΑΝΔΡΑΒΙΔΑΣ - ΚΥΛΛΗΝΗΣ/ΗΛΕΙΑΣ</option>
                            <option value='ΑΝΔΡΙΤΣΑΙΝΑΣ - ΚΡΕΣΤΕΝΩΝ/ΗΛΕΙΑΣ'>ΑΝΔΡΙΤΣΑΙΝΑΣ - ΚΡΕΣΤΕΝΩΝ/ΗΛΕΙΑΣ</option>
                            <option value='ΑΝΔΡΟΥ/ΚΥΚΛΑΔΩΝ'>ΑΝΔΡΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΑΝΤΙΠΑΡΟΥ/ΚΥΚΛΑΔΩΝ'>ΑΝΤΙΠΑΡΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΑΝΩΓΕΙΩΝ/ΡΕΘΥΜΝΗΣ'>ΑΝΩΓΕΙΩΝ/ΡΕΘΥΜΝΗΣ</option>
                            <option value='ΑΠΟΚΟΡΩΝΟΥ/ΧΑΝΙΩΝ'>ΑΠΟΚΟΡΩΝΟΥ/ΧΑΝΙΩΝ</option>
                            <option value='ΑΡΓΙΘΕΑΣ/ΚΑΡΔΙΤΣΗΣ'>ΑΡΓΙΘΕΑΣ/ΚΑΡΔΙΤΣΗΣ</option>
                            <option value='ΑΡΓΟΥΣ - ΜΥΚΗΝΩΝ/ΑΡΓΟΛΙΔΟΣ'>ΑΡΓΟΥΣ - ΜΥΚΗΝΩΝ/ΑΡΓΟΛΙΔΟΣ</option>
                            <option value='ΑΡΓΟΥΣ ΟΡΕΣΤΙΚΟΥ/ΚΑΣΤΟΡΙΑΣ'>ΑΡΓΟΥΣ ΟΡΕΣΤΙΚΟΥ/ΚΑΣΤΟΡΙΑΣ</option>
                            <option value='ΑΡΙΣΤΟΤΕΛΗ/ΧΑΛΚΙΔΙΚΗΣ'>ΑΡΙΣΤΟΤΕΛΗ/ΧΑΛΚΙΔΙΚΗΣ</option>
                            <option value='ΑΡΡΙΑΝΩΝ/ΡΟΔΟΠΗΣ'>ΑΡΡΙΑΝΩΝ/ΡΟΔΟΠΗΣ</option>
                            <option value='ΑΡΤΑΙΩΝ/ΑΡΤΗΣ'>ΑΡΤΑΙΩΝ/ΑΡΤΗΣ</option>
                            <option value='ΑΡΧΑΙΑΣ ΟΛΥΜΠΙΑΣ/ΗΛΕΙΑΣ'>ΑΡΧΑΙΑΣ ΟΛΥΜΠΙΑΣ/ΗΛΕΙΑΣ</option>
                            <option value='ΑΡΧΑΝΩΝ - ΑΣΤΕΡΟΥΣΙΩΝ/ΗΡΑΚΛΕΙΟΥ'>ΑΡΧΑΝΩΝ - ΑΣΤΕΡΟΥΣΙΩΝ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΑΣΠΡΟΠΥΡΓΟΥ/ΑΤΤΙΚΗΣ'>ΑΣΠΡΟΠΥΡΓΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΑΣΤΥΠΑΛΑΙΑΣ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΑΣΤΥΠΑΛΑΙΑΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΑΧΑΡΝΩΝ/ΑΤΤΙΚΗΣ'>ΑΧΑΡΝΩΝ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΒΑΡΗΣ - ΒΟΥΛΑΣ - ΒΟΥΛΙΑΓΜΕΝΗΣ/ΑΤΤΙΚΗΣ'>ΒΑΡΗΣ - ΒΟΥΛΑΣ - ΒΟΥΛΙΑΓΜΕΝΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΒΕΛΟΥ - ΒΟΧΑΣ/ΚΟΡΙΝΘΙΑΣ'>ΒΕΛΟΥ - ΒΟΧΑΣ/ΚΟΡΙΝΘΙΑΣ</option>
                            <option value='ΒΕΡΟΙΑΣ/ΗΜΑΘΙΑΣ'>ΒΕΡΟΙΑΣ/ΗΜΑΘΙΑΣ</option>
                            <option value='ΒΙΑΝΝΟΥ/ΗΡΑΚΛΕΙΟΥ'>ΒΙΑΝΝΟΥ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΒΙΣΑΛΤΙΑΣ/ΣΕΡΡΩΝ'>ΒΙΣΑΛΤΙΑΣ/ΣΕΡΡΩΝ</option>
                            <option value='ΒΟΙΟΥ/ΚΟΖΑΝΗΣ'>ΒΟΙΟΥ/ΚΟΖΑΝΗΣ</option>
                            <option value='ΒΟΛΒΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΒΟΛΒΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΒΟΛΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΒΟΛΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΒΟΡΕΙΑΣ ΚΥΝΟΥΡΙΑΣ/ΑΡΚΑΔΙΑΣ'>ΒΟΡΕΙΑΣ ΚΥΝΟΥΡΙΑΣ/ΑΡΚΑΔΙΑΣ</option>
                            <option value='ΒΟΡΕΙΩΝ ΤΖΟΥΜΕΡΚΩΝ/ΙΩΑΝΝΙΝΩΝ'>ΒΟΡΕΙΩΝ ΤΖΟΥΜΕΡΚΩΝ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΒΡΙΛΗΣΣΙΩΝ/ΑΤΤΙΚΗΣ'>ΒΡΙΛΗΣΣΙΩΝ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΒΥΡΩΝΟΣ/ΑΤΤΙΚΗΣ'>ΒΥΡΩΝΟΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΓΑΛΑΤΣΙΟΥ/ΑΤΤΙΚΗΣ'>ΓΑΛΑΤΣΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΓΑΥΔΟΥ/ΧΑΝΙΩΝ'>ΓΑΥΔΟΥ/ΧΑΝΙΩΝ</option>
                            <option value='ΓΕΩΡΓΙΟΥ ΚΑΡΑΙΣΚΑΚΗ/ΑΡΤΗΣ'>ΓΕΩΡΓΙΟΥ ΚΑΡΑΙΣΚΑΚΗ/ΑΡΤΗΣ</option>
                            <option value='ΓΛΥΦΑΔΑΣ/ΑΤΤΙΚΗΣ'>ΓΛΥΦΑΔΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΓΟΡΤΥΝΑΣ/ΗΡΑΚΛΕΙΟΥ'>ΓΟΡΤΥΝΑΣ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΓΟΡΤΥΝΙΑΣ/ΑΡΚΑΔΙΑΣ'>ΓΟΡΤΥΝΙΑΣ/ΑΡΚΑΔΙΑΣ</option>
                            <option value='ΓΡΕΒΕΝΩΝ/ΓΡΕΒΕΝΩΝ'>ΓΡΕΒΕΝΩΝ/ΓΡΕΒΕΝΩΝ</option>
                            <option value='ΔΑΦΝΗΣ - ΥΜΗΤΤΟΥ/ΑΤΤΙΚΗΣ'>ΔΑΦΝΗΣ - ΥΜΗΤΤΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΔΕΛΤΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΔΕΛΤΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΔΕΛΦΩΝ/ΦΩΚΙΔΟΣ'>ΔΕΛΦΩΝ/ΦΩΚΙΔΟΣ</option>
                            <option value='ΔΕΣΚΑΤΗΣ/ΓΡΕΒΕΝΩΝ'>ΔΕΣΚΑΤΗΣ/ΓΡΕΒΕΝΩΝ</option>
                            <option value='ΔΙΔΥΜΟΤΕΙΧΟΥ/ΕΒΡΟΥ'>ΔΙΔΥΜΟΤΕΙΧΟΥ/ΕΒΡΟΥ</option>
                            <option value='ΔΙΟΝΥΣΟΥ/ΑΤΤΙΚΗΣ'>ΔΙΟΝΥΣΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΔΙΟΥ - ΟΛΥΜΠΟΥ/ΠΙΕΡΙΑΣ'>ΔΙΟΥ - ΟΛΥΜΠΟΥ/ΠΙΕΡΙΑΣ</option>
                            <option value='ΔΙΡΦΥΩΝ - ΜΕΣΣΑΠΙΩΝ/ΕΥΒΟΙΑΣ'>ΔΙΡΦΥΩΝ - ΜΕΣΣΑΠΙΩΝ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΔΙΣΤΟΜΟΥ - ΑΡΑΧΟΒΑΣ - ΑΝΤΙΚΥΡΑΣ/ΒΟΙΩΤΙΑΣ'>ΔΙΣΤΟΜΟΥ - ΑΡΑΧΟΒΑΣ - ΑΝΤΙΚΥΡΑΣ/ΒΟΙΩΤΙΑΣ</option>
                            <option value='ΔΟΜΟΚΟΥ/ΦΘΙΩΤΙΔΟΣ'>ΔΟΜΟΚΟΥ/ΦΘΙΩΤΙΔΟΣ</option>
                            <option value='ΔΟΞΑΤΟΥ/ΔΡΑΜΑΣ'>ΔΟΞΑΤΟΥ/ΔΡΑΜΑΣ</option>
                            <option value='ΔΡΑΜΑΣ/ΔΡΑΜΑΣ'>ΔΡΑΜΑΣ/ΔΡΑΜΑΣ</option>
                            <option value='ΔΥΤΙΚΗΣ ΑΧΑΙΑΣ/ΑΧΑΪΑΣ'>ΔΥΤΙΚΗΣ ΑΧΑΙΑΣ/ΑΧΑΪΑΣ</option>
                            <option value='ΔΥΤΙΚΗΣ ΜΑΝΗΣ/ΜΕΣΣΗΝΙΑΣ'>ΔΥΤΙΚΗΣ ΜΑΝΗΣ/ΜΕΣΣΗΝΙΑΣ</option>
                            <option value='ΔΩΔΩΝΗΣ/ΙΩΑΝΝΙΝΩΝ'>ΔΩΔΩΝΗΣ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΔΩΡΙΔΟΣ/ΦΩΚΙΔΟΣ'>ΔΩΡΙΔΟΣ/ΦΩΚΙΔΟΣ</option>
                            <option value='ΕΔΕΣΣΑΣ/ΠΕΛΛΗΣ'>ΕΔΕΣΣΑΣ/ΠΕΛΛΗΣ</option>
                            <option value='ΕΛΑΣΣΟΝΑΣ/ΛΑΡΙΣΗΣ'>ΕΛΑΣΣΟΝΑΣ/ΛΑΡΙΣΗΣ</option>
                            <option value='ΕΛΑΦΟΝΗΣΟΥ/ΛΑΚΩΝΙΑΣ'>ΕΛΑΦΟΝΗΣΟΥ/ΛΑΚΩΝΙΑΣ</option>
                            <option value='ΕΛΕΥΣΙΝΑΣ/ΑΤΤΙΚΗΣ'>ΕΛΕΥΣΙΝΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΕΛΛΗΝΙΚΟΥ - ΑΡΓΥΡΟΥΠΟΛΗΣ/ΑΤΤΙΚΗΣ'>ΕΛΛΗΝΙΚΟΥ - ΑΡΓΥΡΟΥΠΟΛΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΕΜΜΑΝΟΥΗΛ ΠΑΠΠΑ/ΣΕΡΡΩΝ'>ΕΜΜΑΝΟΥΗΛ ΠΑΠΠΑ/ΣΕΡΡΩΝ</option>
                            <option value='ΕΟΡΔΑΙΑΣ/ΚΟΖΑΝΗΣ'>ΕΟΡΔΑΙΑΣ/ΚΟΖΑΝΗΣ</option>
                            <option value='ΕΠΙΔΑΥΡΟΥ/ΑΡΓΟΛΙΔΟΣ'>ΕΠΙΔΑΥΡΟΥ/ΑΡΓΟΛΙΔΟΣ</option>
                            <option value='ΕΡΕΤΡΙΑΣ/ΕΥΒΟΙΑΣ'>ΕΡΕΤΡΙΑΣ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΕΡΜΙΟΝΙΔΑΣ/ΑΡΓΟΛΙΔΟΣ'>ΕΡΜΙΟΝΙΔΑΣ/ΑΡΓΟΛΙΔΟΣ</option>
                            <option value='ΕΡΥΜΑΝΘΟΥ/ΑΧΑΪΑΣ'>ΕΡΥΜΑΝΘΟΥ/ΑΧΑΪΑΣ</option>
                            <option value='ΕΥΡΩΤΑ/ΛΑΚΩΝΙΑΣ'>ΕΥΡΩΤΑ/ΛΑΚΩΝΙΑΣ</option>
                            <option value='ΖΑΓΟΡΑΣ - ΜΟΥΡΕΣΙΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΖΑΓΟΡΑΣ - ΜΟΥΡΕΣΙΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΖΑΓΟΡΙΟΥ/ΙΩΑΝΝΙΝΩΝ'>ΖΑΓΟΡΙΟΥ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΖΑΚΥΝΘΟΥ/ΖΑΚΥΝΘΟΥ'>ΖΑΚΥΝΘΟΥ/ΖΑΚΥΝΘΟΥ</option>
                            <option value='ΖΑΧΑΡΩΣ/ΗΛΕΙΑΣ'>ΖΑΧΑΡΩΣ/ΗΛΕΙΑΣ</option>
                            <option value='ΖΗΡΟΥ/ΠΡΕΒΕΖΗΣ'>ΖΗΡΟΥ/ΠΡΕΒΕΖΗΣ</option>
                            <option value='ΖΙΤΣΑΣ/ΙΩΑΝΝΙΝΩΝ'>ΖΙΤΣΑΣ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΖΩΓΡΑΦΟΥ/ΑΤΤΙΚΗΣ'>ΖΩΓΡΑΦΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΗΓΟΥΜΕΝΙΤΣΑΣ/ΘΕΣΠΡΩΤΙΑΣ'>ΗΓΟΥΜΕΝΙΤΣΑΣ/ΘΕΣΠΡΩΤΙΑΣ</option>
                            <option value='ΗΛΙΔΑΣ/ΗΛΕΙΑΣ'>ΗΛΙΔΑΣ/ΗΛΕΙΑΣ</option>
                            <option value='ΗΛΙΟΥΠΟΛΕΩΣ/ΑΤΤΙΚΗΣ'>ΗΛΙΟΥΠΟΛΕΩΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΗΡΑΚΛΕΙΑΣ/ΣΕΡΡΩΝ'>ΗΡΑΚΛΕΙΑΣ/ΣΕΡΡΩΝ</option>
                            <option value='ΗΡΑΚΛΕΙΟΥ/ΑΤΤΙΚΗΣ'>ΗΡΑΚΛΕΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΗΡΑΚΛΕΙΟΥ/ΗΡΑΚΛΕΙΟΥ'>ΗΡΑΚΛΕΙΟΥ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΗΡΩΙΚΗΣ ΝΗΣΟΥ ΚΑΣΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΗΡΩΙΚΗΣ ΝΗΣΟΥ ΚΑΣΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΗΡΩΙΚΗΣ ΝΗΣΟΥ ΨΑΡΩΝ/ΧΙΟΥ'>ΗΡΩΙΚΗΣ ΝΗΣΟΥ ΨΑΡΩΝ/ΧΙΟΥ</option>
                            <option value='ΗΡΩΙΚΗΣ ΠΟΛΕΩΣ ΝΑΟΥΣΑΣ/ΗΜΑΘΙΑΣ'>ΗΡΩΙΚΗΣ ΠΟΛΕΩΣ ΝΑΟΥΣΑΣ/ΗΜΑΘΙΑΣ</option>
                            <option value='ΘΑΣΟΥ/ΚΑΒΑΛΑΣ'>ΘΑΣΟΥ/ΚΑΒΑΛΑΣ</option>
                            <option value='ΘΕΡΜΑΙΚΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΘΕΡΜΑΙΚΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΘΕΡΜΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΘΕΡΜΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΘΕΡΜΟΥ/ΑΙΤΩΛ/ΝΙΑΣ'>ΘΕΡΜΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option>
                            <option value='ΘΕΣΣΑΛΟΝΙΚΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΘΕΣΣΑΛΟΝΙΚΗΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΘΗΒΑΙΩΝ/ΒΟΙΩΤΙΑΣ'>ΘΗΒΑΙΩΝ/ΒΟΙΩΤΙΑΣ</option>
                            <option value='ΘΗΡΑΣ/ΚΥΚΛΑΔΩΝ'>ΘΗΡΑΣ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΙΑΣΜΟΥ/ΡΟΔΟΠΗΣ'>ΙΑΣΜΟΥ/ΡΟΔΟΠΗΣ</option>
                            <option value='ΙΕΡΑΠΕΤΡΑΣ/ΛΑΣΙΘΙΟΥ'>ΙΕΡΑΠΕΤΡΑΣ/ΛΑΣΙΘΙΟΥ</option>
                            <option value='ΙΕΡΑΣ ΠΟΛΗΣ ΜΕΣΟΛΟΓΓΙΟΥ/ΑΙΤΩΛ/ΝΙΑΣ'>ΙΕΡΑΣ ΠΟΛΗΣ ΜΕΣΟΛΟΓΓΙΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option>
                            <option value='ΙΗΤΩΝ/ΚΥΚΛΑΔΩΝ'>ΙΗΤΩΝ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΙΘΑΚΗΣ/ΚΕΦΑΛΛΗΝΙΑΣ'>ΙΘΑΚΗΣ/ΚΕΦΑΛΛΗΝΙΑΣ</option>
                            <option value='ΙΚΑΡΙΑΣ /ΣΑΜΟΥ'>ΙΚΑΡΙΑΣ /ΣΑΜΟΥ</option>
                            <option value='ΙΛΙΟΥ (ΝΕΩΝ ΛΙΟΣΙΩΝ)/ΑΤΤΙΚΗΣ'>ΙΛΙΟΥ (ΝΕΩΝ ΛΙΟΣΙΩΝ)/ΑΤΤΙΚΗΣ</option>
                            <option value='ΙΣΤΙΑΙΑΣ - ΑΙΔΗΨΟΥ/ΕΥΒΟΙΑΣ'>ΙΣΤΙΑΙΑΣ - ΑΙΔΗΨΟΥ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΙΩΑΝΝΙΤΩΝ/ΙΩΑΝΝΙΝΩΝ'>ΙΩΑΝΝΙΤΩΝ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΚΑΒΑΛΑΣ/ΚΑΒΑΛΑΣ'>ΚΑΒΑΛΑΣ/ΚΑΒΑΛΑΣ</option>
                            <option value='ΚΑΙΣΑΡΙΑΝΗΣ/ΑΤΤΙΚΗΣ'>ΚΑΙΣΑΡΙΑΝΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΚΑΛΑΒΡΥΤΩΝ/ΑΧΑΪΑΣ'>ΚΑΛΑΒΡΥΤΩΝ/ΑΧΑΪΑΣ</option>
                            <option value='ΚΑΛΑΜΑΡΙΑΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΚΑΛΑΜΑΡΙΑΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΚΑΛΑΜΑΤΑΣ/ΜΕΣΣΗΝΙΑΣ'>ΚΑΛΑΜΑΤΑΣ/ΜΕΣΣΗΝΙΑΣ</option>
                            <option value='ΚΑΛΛΙΘΕΑΣ/ΑΤΤΙΚΗΣ'>ΚΑΛΛΙΘΕΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΚΑΛΥΜΝΙΩΝ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΚΑΛΥΜΝΙΩΝ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΚΑΜΕΝΩΝ ΒΟΥΡΛΩΝ/ΦΘΙΩΤΙΔΟΣ'>ΚΑΜΕΝΩΝ ΒΟΥΡΛΩΝ/ΦΘΙΩΤΙΔΟΣ</option>
                            <option value='ΚΑΝΤΑΝΟΥ - ΣΕΛΙΝΟΥ/ΧΑΝΙΩΝ'>ΚΑΝΤΑΝΟΥ - ΣΕΛΙΝΟΥ/ΧΑΝΙΩΝ</option>
                            <option value='ΚΑΡΔΙΤΣΑΣ/ΚΑΡΔΙΤΣΗΣ'>ΚΑΡΔΙΤΣΑΣ/ΚΑΡΔΙΤΣΗΣ</option>
                            <option value='ΚΑΡΠΑΘΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΚΑΡΠΑΘΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΚΑΡΠΕΝΗΣΙΟΥ/ΕΥΡΥΤΑΝΙΑΣ'>ΚΑΡΠΕΝΗΣΙΟΥ/ΕΥΡΥΤΑΝΙΑΣ</option>
                            <option value='ΚΑΡΥΣΤΟΥ/ΕΥΒΟΙΑΣ'>ΚΑΡΥΣΤΟΥ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΚΑΣΣΑΝΔΡΑΣ/ΧΑΛΚΙΔΙΚΗΣ'>ΚΑΣΣΑΝΔΡΑΣ/ΧΑΛΚΙΔΙΚΗΣ</option>
                            <option value='ΚΑΣΤΟΡΙΑΣ/ΚΑΣΤΟΡΙΑΣ'>ΚΑΣΤΟΡΙΑΣ/ΚΑΣΤΟΡΙΑΣ</option>
                            <option value='ΚΑΤΕΡΙΝΗΣ/ΠΙΕΡΙΑΣ'>ΚΑΤΕΡΙΝΗΣ/ΠΙΕΡΙΑΣ</option>
                            <option value='ΚΑΤΩ ΝΕΥΡΟΚΟΠΙΟΥ/ΔΡΑΜΑΣ'>ΚΑΤΩ ΝΕΥΡΟΚΟΠΙΟΥ/ΔΡΑΜΑΣ</option>
                            <option value='ΚΕΑΣ/ΚΥΚΛΑΔΩΝ'>ΚΕΑΣ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΚΕΝΤΡΙΚΩΝ ΤΖΟΥΜΕΡΚΩΝ /ΑΡΤΗΣ'>ΚΕΝΤΡΙΚΩΝ ΤΖΟΥΜΕΡΚΩΝ /ΑΡΤΗΣ</option>
                            <option value='ΚΕΡΑΤΣΙΝΙΟΥ - ΔΡΑΠΕΤΣΩΝΑΣ/ΑΤΤΙΚΗΣ'>ΚΕΡΑΤΣΙΝΙΟΥ - ΔΡΑΠΕΤΣΩΝΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΚΕΡΚΥΡΑΣ/ΚΕΡΚΥΡΑΣ'>ΚΕΡΚΥΡΑΣ/ΚΕΡΚΥΡΑΣ</option>
                            <option value='ΚΕΦΑΛΟΝΙΑΣ/ΚΕΦΑΛΛΗΝΙΑΣ'>ΚΕΦΑΛΟΝΙΑΣ/ΚΕΦΑΛΛΗΝΙΑΣ</option>
                            <option value='ΚΗΦΙΣΙΑΣ/ΑΤΤΙΚΗΣ'>ΚΗΦΙΣΙΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΚΙΛΕΛΕΡ/ΛΑΡΙΣΗΣ'>ΚΙΛΕΛΕΡ/ΛΑΡΙΣΗΣ</option>
                            <option value='ΚΙΛΚΙΣ/ΚΙΛΚΙΣ'>ΚΙΛΚΙΣ/ΚΙΛΚΙΣ</option>
                            <option value='ΚΙΜΩΛΟΥ/ΚΥΚΛΑΔΩΝ'>ΚΙΜΩΛΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΚΙΣΣΑΜΟΥ/ΧΑΝΙΩΝ'>ΚΙΣΣΑΜΟΥ/ΧΑΝΙΩΝ</option>
                            <option value='ΚΟΖΑΝΗΣ/ΚΟΖΑΝΗΣ'>ΚΟΖΑΝΗΣ/ΚΟΖΑΝΗΣ</option>
                            <option value='ΚΟΜΟΤΗΝΗΣ/ΡΟΔΟΠΗΣ'>ΚΟΜΟΤΗΝΗΣ/ΡΟΔΟΠΗΣ</option>
                            <option value='ΚΟΝΙΤΣΑΣ/ΙΩΑΝΝΙΝΩΝ'>ΚΟΝΙΤΣΑΣ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΚΟΡΔΕΛΙΟΥ -ΕΥΟΣΜΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΚΟΡΔΕΛΙΟΥ -ΕΥΟΣΜΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΚΟΡΙΝΘΙΩΝ/ΚΟΡΙΝΘΙΑΣ'>ΚΟΡΙΝΘΙΩΝ/ΚΟΡΙΝΘΙΑΣ</option>
                            <option value='ΚΟΡΥΔΑΛΛΟΥ/ΑΤΤΙΚΗΣ'>ΚΟΡΥΔΑΛΛΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΚΡΩΠΙΑΣ/ΑΤΤΙΚΗΣ'>ΚΡΩΠΙΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΚΥΘΗΡΩΝ/ΑΤΤΙΚΗΣ'>ΚΥΘΗΡΩΝ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΚΥΘΝΟΥ/ΚΥΚΛΑΔΩΝ'>ΚΥΘΝΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΚΥΜΗΣ - ΑΛΙΒΕΡΙΟΥ/ΕΥΒΟΙΑΣ'>ΚΥΜΗΣ - ΑΛΙΒΕΡΙΟΥ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΚΩ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΚΩ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΛΑΓΚΑΔΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΛΑΓΚΑΔΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΛΑΜΙΕΩΝ/ΦΘΙΩΤΙΔΟΣ'>ΛΑΜΙΕΩΝ/ΦΘΙΩΤΙΔΟΣ</option>
                            <option value='ΛΑΡΙΣΑΙΩΝ/ΛΑΡΙΣΗΣ'>ΛΑΡΙΣΑΙΩΝ/ΛΑΡΙΣΗΣ</option>
                            <option value='ΛΑΥΡΕΩΤΙΚΗΣ/ΑΤΤΙΚΗΣ'>ΛΑΥΡΕΩΤΙΚΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΛΕΒΑΔΕΩΝ/ΒΟΙΩΤΙΑΣ'>ΛΕΒΑΔΕΩΝ/ΒΟΙΩΤΙΑΣ</option>
                            <option value='ΛΕΙΨΩΝ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΛΕΙΨΩΝ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΛΕΡΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΛΕΡΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΛΕΣΒΟΥ/ΛΕΣΒΟΥ'>ΛΕΣΒΟΥ/ΛΕΣΒΟΥ</option>
                            <option value='ΛΕΥΚΑΔΑΣ/ΛΕΥΚΑΔΟΣ'>ΛΕΥΚΑΔΑΣ/ΛΕΥΚΑΔΟΣ</option>
                            <option value='ΛΗΜΝΟΥ/ΛΕΣΒΟΥ'>ΛΗΜΝΟΥ/ΛΕΣΒΟΥ</option>
                            <option value='ΛΙΜΝΗΣ ΠΛΑΣΤΗΡΑ/ΚΑΡΔΙΤΣΗΣ'>ΛΙΜΝΗΣ ΠΛΑΣΤΗΡΑ/ΚΑΡΔΙΤΣΗΣ</option>
                            <option value='ΛΟΚΡΩΝ/ΦΘΙΩΤΙΔΟΣ'>ΛΟΚΡΩΝ/ΦΘΙΩΤΙΔΟΣ</option>
                            <option value='ΛΟΥΤΡΑΚΙΟΥ-ΠΕΡΑΧΩΡΑΣ-ΑΓΙΩΝ ΘΕΟΔΩΡΩΝ/ΚΟΡΙΝΘΙΑΣ'>ΛΟΥΤΡΑΚΙΟΥ-ΠΕΡΑΧΩΡΑΣ-ΑΓΙΩΝ ΘΕΟΔΩΡΩΝ/ΚΟΡΙΝΘΙΑΣ</option>
                            <option value='ΛΥΚΟΒΡΥΣΗΣ - ΠΕΥΚΗΣ/ΑΤΤΙΚΗΣ'>ΛΥΚΟΒΡΥΣΗΣ - ΠΕΥΚΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΜΑΚΡΑΚΩΜΗΣ/ΦΘΙΩΤΙΔΟΣ'>ΜΑΚΡΑΚΩΜΗΣ/ΦΘΙΩΤΙΔΟΣ</option>
                            <option value='ΜΑΛΕΒΙΖΙΟΥ/ΗΡΑΚΛΕΙΟΥ'>ΜΑΛΕΒΙΖΙΟΥ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΜΑΝΔΡΑΣ - ΕΙΔΥΛΛΙΑΣ/ΑΤΤΙΚΗΣ'>ΜΑΝΔΡΑΣ - ΕΙΔΥΛΛΙΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΜΑΝΤΟΥΔΙΟΥ - ΛΙΜΝΗΣ - ΑΓΙΑΣ ΑΝΝΑΣ/ΕΥΒΟΙΑΣ'>ΜΑΝΤΟΥΔΙΟΥ - ΛΙΜΝΗΣ - ΑΓΙΑΣ ΑΝΝΑΣ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΜΑΡΑΘΩΝΟΣ/ΑΤΤΙΚΗΣ'>ΜΑΡΑΘΩΝΟΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΜΑΡΚΟΠΟΥΛΟΥ ΜΕΣΟΓΑΙΑΣ/ΑΤΤΙΚΗΣ'>ΜΑΡΚΟΠΟΥΛΟΥ ΜΕΣΟΓΑΙΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΜΑΡΩΝΕΙΑΣ - ΣΑΠΩΝ/ΡΟΔΟΠΗΣ'>ΜΑΡΩΝΕΙΑΣ - ΣΑΠΩΝ/ΡΟΔΟΠΗΣ</option>
                            <option value='ΜΕΓΑΛΟΠΟΛΗΣ/ΑΡΚΑΔΙΑΣ'>ΜΕΓΑΛΟΠΟΛΗΣ/ΑΡΚΑΔΙΑΣ</option>
                            <option value='ΜΕΓΑΝΗΣΙΟΥ/ΛΕΥΚΑΔΟΣ'>ΜΕΓΑΝΗΣΙΟΥ/ΛΕΥΚΑΔΟΣ</option>
                            <option value='ΜΕΓΑΡΕΩΝ/ΑΤΤΙΚΗΣ'>ΜΕΓΑΡΕΩΝ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΜΕΓΙΣΤΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΜΕΓΙΣΤΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΜΕΣΣΗΝΗΣ/ΜΕΣΣΗΝΙΑΣ'>ΜΕΣΣΗΝΗΣ/ΜΕΣΣΗΝΙΑΣ</option>
                            <option value='ΜΕΤΑΜΟΡΦΩΣΕΩΣ/ΑΤΤΙΚΗΣ'>ΜΕΤΑΜΟΡΦΩΣΕΩΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΜΕΤΕΩΡΩΝ/ΤΡΙΚΑΛΩΝ'>ΜΕΤΕΩΡΩΝ/ΤΡΙΚΑΛΩΝ</option>
                            <option value='ΜΕΤΣΟΒΟΥ/ΙΩΑΝΝΙΝΩΝ'>ΜΕΤΣΟΒΟΥ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΜΗΛΟΥ/ΚΥΚΛΑΔΩΝ'>ΜΗΛΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΜΙΝΩΑ ΠΕΔΙΑΔΟΣ/ΗΡΑΚΛΕΙΟΥ'>ΜΙΝΩΑ ΠΕΔΙΑΔΟΣ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΜΟΝΕΜΒΑΣΙΑΣ/ΛΑΚΩΝΙΑΣ'>ΜΟΝΕΜΒΑΣΙΑΣ/ΛΑΚΩΝΙΑΣ</option>
                            <option value='ΜΟΣΧΑΤΟΥ - ΤΑΥΡΟΥ/ΑΤΤΙΚΗΣ'>ΜΟΣΧΑΤΟΥ - ΤΑΥΡΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΜΟΥΖΑΚΙΟΥ/ΚΑΡΔΙΤΣΗΣ'>ΜΟΥΖΑΚΙΟΥ/ΚΑΡΔΙΤΣΗΣ</option>
                            <option value='ΜΥΚΗΣ/ΞΑΝΘΗΣ'>ΜΥΚΗΣ/ΞΑΝΘΗΣ</option>
                            <option value='ΜΥΚΟΝΟΥ/ΚΥΚΛΑΔΩΝ'>ΜΥΚΟΝΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΜΥΛΟΠΟΤΑΜΟΥ/ΡΕΘΥΜΝΗΣ'>ΜΥΛΟΠΟΤΑΜΟΥ/ΡΕΘΥΜΝΗΣ</option>
                            <option value='ΝΑΞΟΥ & ΜΙΚΡΩΝ ΚΥΚΛΑΔΩΝ/ΚΥΚΛΑΔΩΝ'>ΝΑΞΟΥ & ΜΙΚΡΩΝ ΚΥΚΛΑΔΩΝ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΝΑΥΠΑΚΤΙΑΣ/ΑΙΤΩΛ/ΝΙΑΣ'>ΝΑΥΠΑΚΤΙΑΣ/ΑΙΤΩΛ/ΝΙΑΣ</option>
                            <option value='ΝΑΥΠΛΙΕΩΝ/ΑΡΓΟΛΙΔΟΣ'>ΝΑΥΠΛΙΕΩΝ/ΑΡΓΟΛΙΔΟΣ</option>
                            <option value='ΝΕΑΠΟΛΗΣ - ΣΥΚΕΩΝ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΝΕΑΠΟΛΗΣ - ΣΥΚΕΩΝ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΝΕΑΣ ΖΙΧΝΗΣ/ΣΕΡΡΩΝ'>ΝΕΑΣ ΖΙΧΝΗΣ/ΣΕΡΡΩΝ</option>
                            <option value='ΝΕΑΣ ΙΩΝΙΑΣ/ΑΤΤΙΚΗΣ'>ΝΕΑΣ ΙΩΝΙΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΝΕΑΣ ΠΡΟΠΟΝΤΙΔΑΣ/ΧΑΛΚΙΔΙΚΗΣ'>ΝΕΑΣ ΠΡΟΠΟΝΤΙΔΑΣ/ΧΑΛΚΙΔΙΚΗΣ</option>
                            <option value='ΝΕΑΣ ΣΜΥΡΝΗΣ/ΑΤΤΙΚΗΣ'>ΝΕΑΣ ΣΜΥΡΝΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΝΕΑΣ ΦΙΛΑΔΕΛΦΕΙΑΣ - ΝΕΑΣ ΧΑΛΚΗΔΟΝΑΣ/ΑΤΤΙΚΗΣ'>ΝΕΑΣ ΦΙΛΑΔΕΛΦΕΙΑΣ - ΝΕΑΣ ΧΑΛΚΗΔΟΝΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΝΕΜΕΑΣ/ΚΟΡΙΝΘΙΑΣ'>ΝΕΜΕΑΣ/ΚΟΡΙΝΘΙΑΣ</option>
                            <option value='ΝΕΣΤΟΡΙΟΥ/ΚΑΣΤΟΡΙΑΣ'>ΝΕΣΤΟΡΙΟΥ/ΚΑΣΤΟΡΙΑΣ</option>
                            <option value='ΝΕΣΤΟΥ/ΚΑΒΑΛΑΣ'>ΝΕΣΤΟΥ/ΚΑΒΑΛΑΣ</option>
                            <option value='ΝΙΚΑΙΑΣ - ΑΓΙΟΥ ΙΩΑΝΝΗ ΡΕΝΤΗ/ΑΤΤΙΚΗΣ'>ΝΙΚΑΙΑΣ - ΑΓΙΟΥ ΙΩΑΝΝΗ ΡΕΝΤΗ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΝΙΚΟΛΑΟΥ ΣΚΟΥΦΑ/ΑΡΤΗΣ'>ΝΙΚΟΛΑΟΥ ΣΚΟΥΦΑ/ΑΡΤΗΣ</option>
                            <option value='ΝΙΣΥΡΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΝΙΣΥΡΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΝΟΤΙΑΣ ΚΥΝΟΥΡΙΑΣ/ΑΡΚΑΔΙΑΣ'>ΝΟΤΙΑΣ ΚΥΝΟΥΡΙΑΣ/ΑΡΚΑΔΙΑΣ</option>
                            <option value='ΝΟΤΙΟΥ ΠΗΛΙΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΝΟΤΙΟΥ ΠΗΛΙΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΞΑΝΘΗΣ/ΞΑΝΘΗΣ'>ΞΑΝΘΗΣ/ΞΑΝΘΗΣ</option>
                            <option value='ΞΗΡΟΜΕΡΟΥ/ΑΙΤΩΛ/ΝΙΑΣ'>ΞΗΡΟΜΕΡΟΥ/ΑΙΤΩΛ/ΝΙΑΣ</option>
                            <option value='ΞΥΛΟΚΑΣΤΡΟΥ - ΕΥΡΩΣΤΙΝΗΣ/ΚΟΡΙΝΘΙΑΣ'>ΞΥΛΟΚΑΣΤΡΟΥ - ΕΥΡΩΣΤΙΝΗΣ/ΚΟΡΙΝΘΙΑΣ</option>
                            <option value='ΟΙΝΟΥΣΣΩΝ/ΧΙΟΥ'>ΟΙΝΟΥΣΣΩΝ/ΧΙΟΥ</option>
                            <option value='ΟΙΧΑΛΙΑΣ/ΜΕΣΣΗΝΙΑΣ'>ΟΙΧΑΛΙΑΣ/ΜΕΣΣΗΝΙΑΣ</option>
                            <option value='ΟΡΕΣΤΙΑΔΑΣ/ΕΒΡΟΥ'>ΟΡΕΣΤΙΑΔΑΣ/ΕΒΡΟΥ</option>
                            <option value='ΟΡΟΠΕΔΙΟΥ ΛΑΣΙΘΙΟΥ/ΛΑΣΙΘΙΟΥ'>ΟΡΟΠΕΔΙΟΥ ΛΑΣΙΘΙΟΥ/ΛΑΣΙΘΙΟΥ</option>
                            <option value='ΟΡΧΟΜΕΝΟΥ/ΒΟΙΩΤΙΑΣ'>ΟΡΧΟΜΕΝΟΥ/ΒΟΙΩΤΙΑΣ</option>
                            <option value='ΠΑΓΓΑΙΟΥ/ΚΑΒΑΛΑΣ'>ΠΑΓΓΑΙΟΥ/ΚΑΒΑΛΑΣ</option>
                            <option value='ΠΑΙΑΝΙΑΣ/ΑΤΤΙΚΗΣ'>ΠΑΙΑΝΙΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΑΙΟΝΙΑΣ/ΚΙΛΚΙΣ'>ΠΑΙΟΝΙΑΣ/ΚΙΛΚΙΣ</option>
                            <option value='ΠΑΛΑΙΟΥ ΦΑΛΗΡΟΥ/ΑΤΤΙΚΗΣ'>ΠΑΛΑΙΟΥ ΦΑΛΗΡΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΑΛΑΜΑ/ΚΑΡΔΙΤΣΗΣ'>ΠΑΛΑΜΑ/ΚΑΡΔΙΤΣΗΣ</option>
                            <option value='ΠΑΛΛΗΝΗΣ/ΑΤΤΙΚΗΣ'>ΠΑΛΛΗΝΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΑΞΩΝ/ΚΕΡΚΥΡΑΣ'>ΠΑΞΩΝ/ΚΕΡΚΥΡΑΣ</option>
                            <option value='ΠΑΠΑΓΟΥ - ΧΟΛΑΡΓΟΥ/ΑΤΤΙΚΗΣ'>ΠΑΠΑΓΟΥ - ΧΟΛΑΡΓΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΑΡΑΝΕΣΤΙΟΥ/ΔΡΑΜΑΣ'>ΠΑΡΑΝΕΣΤΙΟΥ/ΔΡΑΜΑΣ</option>
                            <option value='ΠΑΡΓΑΣ/ΠΡΕΒΕΖΗΣ'>ΠΑΡΓΑΣ/ΠΡΕΒΕΖΗΣ</option>
                            <option value='ΠΑΡΟΥ/ΚΥΚΛΑΔΩΝ'>ΠΑΡΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΠΑΤΜΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΠΑΤΜΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΠΑΤΡΕΩΝ/ΑΧΑΪΑΣ'>ΠΑΤΡΕΩΝ/ΑΧΑΪΑΣ</option>
                            <option value='ΠΑΥΛΟΥ ΜΕΛΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΠΑΥΛΟΥ ΜΕΛΑ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΠΕΙΡΑΙΩΣ/ΑΤΤΙΚΗΣ'>ΠΕΙΡΑΙΩΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΕΛΛΑΣ/ΠΕΛΛΗΣ'>ΠΕΛΛΑΣ/ΠΕΛΛΗΣ</option>
                            <option value='ΠΕΝΤΕΛΗΣ/ΑΤΤΙΚΗΣ'>ΠΕΝΤΕΛΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΕΡΑΜΑΤΟΣ/ΑΤΤΙΚΗΣ'>ΠΕΡΑΜΑΤΟΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΕΡΙΣΤΕΡΙΟΥ/ΑΤΤΙΚΗΣ'>ΠΕΡΙΣΤΕΡΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΕΤΡΟΥΠΟΛΕΩΣ/ΑΤΤΙΚΗΣ'>ΠΕΤΡΟΥΠΟΛΕΩΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΗΝΕΙΟΥ/ΗΛΕΙΑΣ'>ΠΗΝΕΙΟΥ/ΗΛΕΙΑΣ</option>
                            <option value='ΠΛΑΤΑΝΙΑ/ΧΑΝΙΩΝ'>ΠΛΑΤΑΝΙΑ/ΧΑΝΙΩΝ</option>
                            <option value='ΠΟΛΥΓΥΡΟΥ/ΧΑΛΚΙΔΙΚΗΣ'>ΠΟΛΥΓΥΡΟΥ/ΧΑΛΚΙΔΙΚΗΣ</option>
                            <option value='ΠΟΡΟΥ/ΑΤΤΙΚΗΣ'>ΠΟΡΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΠΡΕΒΕΖΑΣ/ΠΡΕΒΕΖΗΣ'>ΠΡΕΒΕΖΑΣ/ΠΡΕΒΕΖΗΣ</option>
                            <option value='ΠΡΕΣΠΩΝ/ΦΛΩΡΙΝΗΣ'>ΠΡΕΣΠΩΝ/ΦΛΩΡΙΝΗΣ</option>
                            <option value='ΠΡΟΣΟΤΣΑΝΗΣ/ΔΡΑΜΑΣ'>ΠΡΟΣΟΤΣΑΝΗΣ/ΔΡΑΜΑΣ</option>
                            <option value='ΠΥΔΝΑΣ - ΚΟΛΙΝΔΡΟΥ/ΠΙΕΡΙΑΣ'>ΠΥΔΝΑΣ - ΚΟΛΙΝΔΡΟΥ/ΠΙΕΡΙΑΣ</option>
                            <option value='ΠΥΛΑΙΑΣ - ΧΟΡΤΙΑΤΗ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΠΥΛΑΙΑΣ - ΧΟΡΤΙΑΤΗ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΠΥΛΗΣ/ΤΡΙΚΑΛΩΝ'>ΠΥΛΗΣ/ΤΡΙΚΑΛΩΝ</option>
                            <option value='ΠΥΛΟΥ - ΝΕΣΤΟΡΟΣ/ΜΕΣΣΗΝΙΑΣ'>ΠΥΛΟΥ - ΝΕΣΤΟΡΟΣ/ΜΕΣΣΗΝΙΑΣ</option>
                            <option value='ΠΥΡΓΟΥ/ΗΛΕΙΑΣ'>ΠΥΡΓΟΥ/ΗΛΕΙΑΣ</option>
                            <option value='ΠΩΓΩΝΙΟΥ/ΙΩΑΝΝΙΝΩΝ'>ΠΩΓΩΝΙΟΥ/ΙΩΑΝΝΙΝΩΝ</option>
                            <option value='ΡΑΦΗΝΑΣ - ΠΙΚΕΡΜΙΟΥ/ΑΤΤΙΚΗΣ'>ΡΑΦΗΝΑΣ - ΠΙΚΕΡΜΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΡΕΘΥΜΝΗΣ/ΡΕΘΥΜΝΗΣ'>ΡΕΘΥΜΝΗΣ/ΡΕΘΥΜΝΗΣ</option>
                            <option value='ΡΗΓΑ ΦΕΡΑΙΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΡΗΓΑ ΦΕΡΑΙΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΡΟΔΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΡΟΔΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΣΑΛΑΜΙΝΑΣ/ΑΤΤΙΚΗΣ'>ΣΑΛΑΜΙΝΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΣΑΜΟΘΡΑΚΗΣ/ΕΒΡΟΥ'>ΣΑΜΟΘΡΑΚΗΣ/ΕΒΡΟΥ</option>
                            <option value='ΣΑΜΟΥ/ΣΑΜΟΥ'>ΣΑΜΟΥ/ΣΑΜΟΥ</option>
                            <option value='ΣΑΡΩΝΙΚΟΥ/ΑΤΤΙΚΗΣ'>ΣΑΡΩΝΙΚΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΣΕΡΒΙΩΝ - ΒΕΛΒΕΝΤΟΥ /ΚΟΖΑΝΗΣ'>ΣΕΡΒΙΩΝ - ΒΕΛΒΕΝΤΟΥ /ΚΟΖΑΝΗΣ</option>
                            <option value='ΣΕΡΙΦΟΥ/ΚΥΚΛΑΔΩΝ'>ΣΕΡΙΦΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΣΕΡΡΩΝ/ΣΕΡΡΩΝ'>ΣΕΡΡΩΝ/ΣΕΡΡΩΝ</option>
                            <option value='ΣΗΤΕΙΑΣ/ΛΑΣΙΘΙΟΥ'>ΣΗΤΕΙΑΣ/ΛΑΣΙΘΙΟΥ</option>
                            <option value='ΣΙΘΩΝΙΑΣ/ΧΑΛΚΙΔΙΚΗΣ'>ΣΙΘΩΝΙΑΣ/ΧΑΛΚΙΔΙΚΗΣ</option>
                            <option value='ΣΙΚΙΝΟΥ/ΚΥΚΛΑΔΩΝ'>ΣΙΚΙΝΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΣΙΚΥΩΝΙΩΝ/ΚΟΡΙΝΘΙΑΣ'>ΣΙΚΥΩΝΙΩΝ/ΚΟΡΙΝΘΙΑΣ</option>
                            <option value='ΣΙΝΤΙΚΗΣ/ΣΕΡΡΩΝ'>ΣΙΝΤΙΚΗΣ/ΣΕΡΡΩΝ</option>
                            <option value='ΣΙΦΝΟΥ/ΚΥΚΛΑΔΩΝ'>ΣΙΦΝΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΣΚΙΑΘΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΣΚΙΑΘΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΣΚΟΠΕΛΟΥ/ΜΑΓΝΗΣΙΑΣ'>ΣΚΟΠΕΛΟΥ/ΜΑΓΝΗΣΙΑΣ</option>
                            <option value='ΣΚΥΔΡΑΣ/ΠΕΛΛΗΣ'>ΣΚΥΔΡΑΣ/ΠΕΛΛΗΣ</option>
                            <option value='ΣΚΥΡΟΥ/ΕΥΒΟΙΑΣ'>ΣΚΥΡΟΥ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΣΟΥΛΙΟΥ/ΘΕΣΠΡΩΤΙΑΣ'>ΣΟΥΛΙΟΥ/ΘΕΣΠΡΩΤΙΑΣ</option>
                            <option value='ΣΟΥΦΛΙΟΥ/ΕΒΡΟΥ'>ΣΟΥΦΛΙΟΥ/ΕΒΡΟΥ</option>
                            <option value='ΣΟΦΑΔΩΝ/ΚΑΡΔΙΤΣΗΣ'>ΣΟΦΑΔΩΝ/ΚΑΡΔΙΤΣΗΣ</option>
                            <option value='ΣΠΑΡΤΗΣ/ΛΑΚΩΝΙΑΣ'>ΣΠΑΡΤΗΣ/ΛΑΚΩΝΙΑΣ</option>
                            <option value='ΣΠΑΤΩΝ - ΑΡΤΕΜΙΔΟΣ/ΑΤΤΙΚΗΣ'>ΣΠΑΤΩΝ - ΑΡΤΕΜΙΔΟΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΣΠΕΤΣΩΝ/ΑΤΤΙΚΗΣ'>ΣΠΕΤΣΩΝ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΣΤΥΛΙΔΑΣ/ΦΘΙΩΤΙΔΟΣ'>ΣΤΥΛΙΔΑΣ/ΦΘΙΩΤΙΔΟΣ</option>
                            <option value='ΣΥΜΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΣΥΜΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΣΥΡΟΥ - ΕΡΜΟΥΠΟΛΗΣ/ΚΥΚΛΑΔΩΝ'>ΣΥΡΟΥ - ΕΡΜΟΥΠΟΛΗΣ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΣΦΑΚΙΩΝ/ΧΑΝΙΩΝ'>ΣΦΑΚΙΩΝ/ΧΑΝΙΩΝ</option>
                            <option value='ΤΑΝΑΓΡΑΣ/ΒΟΙΩΤΙΑΣ'>ΤΑΝΑΓΡΑΣ/ΒΟΙΩΤΙΑΣ</option>
                            <option value='ΤΕΜΠΩΝ /ΛΑΡΙΣΗΣ'>ΤΕΜΠΩΝ /ΛΑΡΙΣΗΣ</option>
                            <option value='ΤΗΛΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΤΗΛΟΥ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΤΗΝΟΥ/ΚΥΚΛΑΔΩΝ'>ΤΗΝΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΤΟΠΕΙΡΟΥ/ΞΑΝΘΗΣ'>ΤΟΠΕΙΡΟΥ/ΞΑΝΘΗΣ</option>
                            <option value='ΤΡΙΚΚΑΙΩΝ/ΤΡΙΚΑΛΩΝ'>ΤΡΙΚΚΑΙΩΝ/ΤΡΙΚΑΛΩΝ</option>
                            <option value='ΤΡΙΠΟΛΗΣ/ΑΡΚΑΔΙΑΣ'>ΤΡΙΠΟΛΗΣ/ΑΡΚΑΔΙΑΣ</option>
                            <option value='ΤΡΙΦΥΛΛΙΑΣ/ΜΕΣΣΗΝΙΑΣ'>ΤΡΙΦΥΛΛΙΑΣ/ΜΕΣΣΗΝΙΑΣ</option>
                            <option value='ΤΡΟΙΖΗΝΙΑΣ-ΜΕΘΑΝΩΝ/ΑΤΤΙΚΗΣ'>ΤΡΟΙΖΗΝΙΑΣ-ΜΕΘΑΝΩΝ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΤΥΡΝΑΒΟΥ/ΛΑΡΙΣΗΣ'>ΤΥΡΝΑΒΟΥ/ΛΑΡΙΣΗΣ</option>
                            <option value='ΥΔΡΑΣ/ΑΤΤΙΚΗΣ'>ΥΔΡΑΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΦΑΙΣΤΟΥ/ΗΡΑΚΛΕΙΟΥ'>ΦΑΙΣΤΟΥ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΦΑΡΚΑΔΟΝΑΣ/ΤΡΙΚΑΛΩΝ'>ΦΑΡΚΑΔΟΝΑΣ/ΤΡΙΚΑΛΩΝ</option>
                            <option value='ΦΑΡΣΑΛΩΝ/ΛΑΡΙΣΗΣ'>ΦΑΡΣΑΛΩΝ/ΛΑΡΙΣΗΣ</option>
                            <option value='ΦΙΛΙΑΤΩΝ/ΘΕΣΠΡΩΤΙΑΣ'>ΦΙΛΙΑΤΩΝ/ΘΕΣΠΡΩΤΙΑΣ</option>
                            <option value='ΦΙΛΟΘΕΗΣ - ΨΥΧΙΚΟΥ/ΑΤΤΙΚΗΣ'>ΦΙΛΟΘΕΗΣ - ΨΥΧΙΚΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΦΛΩΡΙΝΑΣ/ΦΛΩΡΙΝΗΣ'>ΦΛΩΡΙΝΑΣ/ΦΛΩΡΙΝΗΣ</option>
                            <option value='ΦΟΛΕΓΑΝΔΡΟΥ/ΚΥΚΛΑΔΩΝ'>ΦΟΛΕΓΑΝΔΡΟΥ/ΚΥΚΛΑΔΩΝ</option>
                            <option value='ΦΟΥΡΝΩΝ ΚΟΡΣΕΩΝ/ΣΑΜΟΥ'>ΦΟΥΡΝΩΝ ΚΟΡΣΕΩΝ/ΣΑΜΟΥ</option>
                            <option value='ΦΥΛΗΣ/ΑΤΤΙΚΗΣ'>ΦΥΛΗΣ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΧΑΙΔΑΡΙΟΥ/ΑΤΤΙΚΗΣ'>ΧΑΙΔΑΡΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΧΑΛΑΝΔΡΙΟΥ/ΑΤΤΙΚΗΣ'>ΧΑΛΑΝΔΡΙΟΥ/ΑΤΤΙΚΗΣ</option>
                            <option value='ΧΑΛΚΗΔΟΝΟΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΧΑΛΚΗΔΟΝΟΣ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΧΑΛΚΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ'>ΧΑΛΚΗΣ/ΔΩΔΕΚΑΝΗΣΟΥ</option>
                            <option value='ΧΑΛΚΙΔΕΩΝ/ΕΥΒΟΙΑΣ'>ΧΑΛΚΙΔΕΩΝ/ΕΥΒΟΙΑΣ</option>
                            <option value='ΧΑΝΙΩΝ/ΧΑΝΙΩΝ'>ΧΑΝΙΩΝ/ΧΑΝΙΩΝ</option>
                            <option value='ΧΕΡΣΟΝΗΣΟΥ/ΗΡΑΚΛΕΙΟΥ'>ΧΕΡΣΟΝΗΣΟΥ/ΗΡΑΚΛΕΙΟΥ</option>
                            <option value='ΧΙΟΥ/ΧΙΟΥ'>ΧΙΟΥ/ΧΙΟΥ</option>
                            <option value='ΩΡΑΙΟΚΑΣΤΡΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ'>ΩΡΑΙΟΚΑΣΤΡΟΥ/ΘΕΣΣΑΛΟΝΙΚΗΣ</option>
                            <option value='ΩΡΩΠΟΥ/ΑΤΤΙΚΗΣ'>ΩΡΩΠΟΥ/ΑΤΤΙΚΗΣ</option>
                        </select>
                        @error('municipality')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>

                <button class="btn btn-block btn-primary mt-4" type="submit">Αποθήκευση Αλλαγών</button>
            </form>
        </div>
    </div>   
</div>
</div>

@endsection
@section('scripts')
<script type="text/javascript">
    $(document).ready(function(){
        $('#sex').val("{{ Auth::user()->sex }}");
        $('#municipality').val("{{ Auth::user()->municipality }}");    

        $( "#updateForm" ).submit(function( event ) {         
            event.preventDefault();  
            $.ajax({
                method: 'PUT',
                dataType: "json",
                url: 'http://127.0.0.1:8001/citizen/update/' + "{{Auth::user()->identity_num}}",
                data: {
                    firstname : $('#firstname').val(),
                    lastname : $('#lastname').val(),
                    email : $('#email').val(),
                    address : $('#address').val(),
                    addressnum : $('#address_num').val(),
                    sex : $('#sex').val(),
                    phone_number : $('#phone').val(),
                    municipallity : $('#municipality').val()
                },
                headers: {
                    Authorization: `Token a29e4590dba36687f14efc90459b0db49a5ef837`
                },
                crossDomain: true
            }).done(function(response){  
                $("#updateForm")[0].submit();
            });
        });
    });

</script>
@endsection