<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <link rel="icon" type="image/x-icon" href="favicon.ico">
   <title>Election-Mng</title>
   <!-- =============== VENDOR STYLES ===============-->
   <!-- FONT AWESOME-->
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-brands.css') }}">
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-regular.css') }}">
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-solid.css') }}">
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fontawesome.css') }}">
   <!-- SIMPLE LINE ICONS-->
   <link rel="stylesheet" href="{{ asset('vendor/simple-line-icons/css/simple-line-icons.css') }}">
   <!-- =============== BOOTSTRAP STYLES ===============-->
   <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}" id="bscss">
   <!-- =============== APP STYLES ===============-->
   <link rel="stylesheet" href="{{ asset('css/app.css') }}" id="maincss">
   <link rel="stylesheet" href="{{ asset('css/theme-e.css') }}" id="maincss">
</head>

<body>
   <div class="row p-5">
      <div class="col-md-12 my-4">
         <h3 class="text-center">NEA ΑΙΤΗΣΗ ΕΤΕΡΟΔΗΜΟΤΗ</h3>
      </div>

      <div class="col-md-12 my-2">
         <div class="float-left">
            <h4>Αριθμός Αίτησης: <span id="listId"></span></h4>
         </div>
         <div class="float-right">
            <h4><?php echo date("l, d/m/Y") ?></h4>
         </div>
      </div>
   </div>

   <div class="col-md-12 my-3">
      <table class="table">
         <tbody>
            <tr>
               <th class="text-right">Δημότης:</th>
               <td id="dimotis"></td>
            </tr>
            <tr>
               <th class="text-right">Πόλη:</th>
               <td id="city"></td>
            </tr>
            <tr>
               <th class="text-right">Οδός:</th>
               <td id="address"></td>
            </tr>
            <tr>
               <th class="text-right">Τηλέφωνο:</th>
               <td id="phone"></td>
            </tr>
            <tr>
               <th class="text-right">ΤΚ:</th>
               <td id="zip"></td>
            </tr>
            <tr>
               <th class="text-right">Ημερομηνία Αιτήματος:</th>
               <td id="date_aitimatos"></td>
            </tr>
         </tbody>
      </table>
   </div>


   <div class="col-md-12 mt-4">
      <h4 class="text-right"> Ο/H Αιτών/ουσα</h4>
      <p class="text-right">{{ Auth::user()->lastname }} {{ Auth::user()->firstname }}</p>
   </div>
   <hr>
</body>

<!-- JQUERY-->
<script src="{{ asset('vendor/jquery/dist/jquery.js') }}"></script>
<script type="text/javascript">

 $(document).ready(function(){
   $('#listId').text(localStorage.getItem('id'));
   $('#dimotis').text(localStorage.getItem('Δημότης'));
   $('#city').text(localStorage.getItem('Πόλη'));
   $('#address').text(localStorage.getItem('Οδός') + " " + localStorage.getItem('Αριθμός'));
   $('#phone').text(localStorage.getItem('Τηλέφωνο'));
   $('#zip').text(localStorage.getItem('ΤΚ'));
   $('#date_aitimatos').text(localStorage.getItem('Ημερομηνία Έκδοσης'));
   localStorage.clear();
   window.print();
   window.location.href = "{{ route('home') }}";
});

</script>
</html>