<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <link rel="icon" type="image/x-icon" href="favicon.ico">
   <title>Election-Mng</title>
   <!-- =============== VENDOR STYLES ===============-->
   <!-- FONT AWESOME-->
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-brands.css') }}">
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-regular.css') }}">
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fa-solid.css') }}">
   <link rel="stylesheet" href="{{ asset('vendor/@fortawesome/fontawesome-free-webfonts/css/fontawesome.css') }}">
   <!-- SIMPLE LINE ICONS-->
   <link rel="stylesheet" href="{{ asset('vendor/simple-line-icons/css/simple-line-icons.css') }}">
   <!-- =============== BOOTSTRAP STYLES ===============-->
   <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}" id="bscss">
   <!-- =============== APP STYLES ===============-->
   <link rel="stylesheet" href="{{ asset('css/app.css') }}" id="maincss">
   <link rel="stylesheet" href="{{ asset('css/theme-e.css') }}" id="maincss">
</head>

<body>
   <div class="wrapper">
     @yield('content')
   </div>
   <!-- =============== VENDOR SCRIPTS ===============-->
   <!-- MODERNIZR-->
   <script src="{{ asset('vendor/modernizr/modernizr.custom.js') }}"></script>
   <!-- JQUERY-->
   <script src="{{ asset('vendor/jquery/dist/jquery.js') }}"></script>
   <!-- BOOTSTRAP-->
   <script src="{{ asset('vendor/bootstrap/dist/js/bootstrap.js') }}"></script>
   <!-- STORAGE API-->
   <script src="{{ asset('vendor/js-storage/js.storage.js') }}"></script>
   <!-- PARSLEY-->
   <script src="{{ asset('vendor/parsleyjs/dist/parsley.js') }}"></script>
   <!-- FILESTYLE-->
   <script src="{{ asset('vendor/bootstrap-filestyle/src/bootstrap-filestyle.js') }}"></script>
   <!-- =============== APP SCRIPTS ===============-->
   <script src="{{ asset('js/app.js') }}"></script>
   @yield('scripts')
   @yield('modals')
</body>

</html>
