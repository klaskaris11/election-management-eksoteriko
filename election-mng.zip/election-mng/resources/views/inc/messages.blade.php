@if(session('success'))
	<div class="alert alert-success bg-success-dark alert-dismissible fade show" role="alert">
		<button class="close" type="button" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
		</button>
		<strong>SUCCESS! </strong> {{session('success')}}
	</div>
@endif

@if ($errors->any())
    <div class="alert alert-danger bg-danger alert-dismissible fade show" role="alert">
    	<button class="close" type="button" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
		</button>
            @foreach ($errors->all() as $error)
              {{ $error }}
            @endforeach
    </div>
@endif
